@echo off
echo ========================================
echo   Creating Deployment Package
echo ========================================
echo.

set PACKAGE_NAME=TailorShop_Deployment
set PACKAGE_DIR=%PACKAGE_NAME%

REM Delete old package if exists
if exist "%PACKAGE_DIR%" (
    echo Removing old package...
    rmdir /s /q "%PACKAGE_DIR%"
)

if exist "%PACKAGE_NAME%.zip" (
    del "%PACKAGE_NAME%.zip"
)

echo Creating package folders...
mkdir "%PACKAGE_DIR%"
mkdir "%PACKAGE_DIR%\dist"
mkdir "%PACKAGE_DIR%\dist\lib"
mkdir "%PACKAGE_DIR%\config"
mkdir "%PACKAGE_DIR%\data"
mkdir "%PACKAGE_DIR%\reports_pdf"
mkdir "%PACKAGE_DIR%\reports_excel"

echo Copying files...

REM Copy main JAR
echo - Copying main application...
copy "dist\TS.jar" "%PACKAGE_DIR%\dist\" >nul

REM Copy libraries
echo - Copying libraries...
copy "dist\lib\*.jar" "%PACKAGE_DIR%\dist\lib\" >nul

REM Copy configuration file
echo - Copying configuration...
copy "config\database.properties" "%PACKAGE_DIR%\config\" >nul

REM Copy launcher script
echo - Copying launcher script...
copy "run.bat" "%PACKAGE_DIR%\" >nul

REM Copy documentation
echo - Copying documentation...
copy "START_HERE.txt" "%PACKAGE_DIR%\" >nul
copy "MASTER_GUIDE.txt" "%PACKAGE_DIR%\" >nul
copy "DEPLOYMENT_GUIDE.txt" "%PACKAGE_DIR%\" >nul
copy "QUICK_START.txt" "%PACKAGE_DIR%\" >nul
copy "CHANGES_LOG.txt" "%PACKAGE_DIR%\" >nul
copy "install_java.bat" "%PACKAGE_DIR%\" >nul

REM Copy README if exists
if exist "dist\README.TXT" (
    copy "dist\README.TXT" "%PACKAGE_DIR%\" >nul
)

echo.
echo ========================================
echo   PACKAGE CREATED SUCCESSFULLY!
echo ========================================
echo.
echo Location: %CD%\%PACKAGE_DIR%
echo.
echo Next steps:
echo 1. Copy the %PACKAGE_DIR% folder to customer
echo 2. Or compress it to ZIP and send
echo.
echo To compress, use any compression tool (WinRAR, 7-Zip, etc.)
echo Or use this command:
echo powershell Compress-Archive -Path %PACKAGE_DIR% -DestinationPath %PACKAGE_NAME%.zip
echo.
pause

