@echo off
echo ========================================
echo    Tailor Shop Management System
echo ========================================
echo.

REM Check if Java is installed
java -version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Java is not installed
    echo Please install Java 17 or higher
    echo Run install_java.bat for help
    echo.
    pause
    exit /b 1
)

REM Create data folder if not exists
if not exist "data" (
    echo Creating database folder...
    mkdir data
)

REM Create reports folders if not exist
if not exist "reports_pdf" mkdir reports_pdf
if not exist "reports_excel" mkdir reports_excel

REM Run the application
echo Starting application...
echo.
java -jar dist\TS.jar

REM Handle errors
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to start application
    echo.
    pause
)

