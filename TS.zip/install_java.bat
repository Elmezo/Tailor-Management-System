@echo off
echo ========================================
echo      Java Installation Helper
echo ========================================
echo.

REM Check if Java is installed
java -version >nul 2>&1
if not errorlevel 1 (
    echo [OK] Java is already installed!
    echo.
    java -version
    echo.
    echo You can now run the application using run.bat
    echo.
    pause
    exit /b 0
)

echo [X] Java is not installed on this computer
echo.
echo This application requires Java 17 or higher
echo.
echo ========================================
echo Download Options:
echo ========================================
echo.
echo 1. Oracle JDK (Official):
echo    https://www.oracle.com/java/technologies/downloads/
echo.
echo 2. Amazon Corretto (Free):
echo    https://aws.amazon.com/corretto/
echo.
echo 3. Microsoft OpenJDK (Recommended for Windows):
echo    https://www.microsoft.com/openjdk
echo.
echo ========================================
echo Installation Steps:
echo ========================================
echo.
echo 1. Choose one of the options above and open the link
echo 2. Download Java 17 or higher for Windows
echo 3. Install Java (Next - Next - Install)
echo 4. Restart your computer
echo 5. Run this file again to verify
echo.
echo ========================================
echo.
echo Do you want to open the download page now?
echo.
choice /C YN /M "Press Y to open website or N to cancel"

if errorlevel 2 goto :end
if errorlevel 1 goto :open_website

:open_website
echo.
echo Opening Microsoft OpenJDK website...
start https://www.microsoft.com/openjdk
goto :end

:end
echo.
pause

