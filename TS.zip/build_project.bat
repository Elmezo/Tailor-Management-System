@echo off
echo ========================================
echo       Building Project
echo ========================================
echo.

REM Check if Java is installed
java -version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Java is not installed
    echo Please install Java 17 or higher
    pause
    exit /b 1
)

echo Step 1: Cleaning project...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
echo [OK] Project cleaned

echo.
echo Step 2: Creating directories...
mkdir dist
mkdir dist\lib
echo [OK] Directories created

echo.
echo Step 3: Copying libraries...
copy lib\*.jar dist\lib\ >nul
echo [OK] Libraries copied

echo.
echo Step 4: Compiling code...
if not exist "build\classes" mkdir build\classes

REM Build classpath
set CP=lib\h2-2.4.240.jar;lib\mysql-connector-j-8.0.33.jar;lib\poi-5.2.5.jar;lib\poi-ooxml-5.2.5.jar
set CP=%CP%;lib\commons-collections4-4.4.jar;lib\commons-compress-1.26.0.jar;lib\commons-io-2.15.1.jar
set CP=%CP%;lib\commons-codec-1.16.0.jar;lib\commons-math3-3.6.1.jar;lib\SparseBitSet-1.3.jar
set CP=%CP%;lib\log4j-api-2.21.1.jar;lib\poi-ooxml-lite-5.2.5.jar;lib\xmlbeans-5.1.1.jar
set CP=%CP%;lib\commons-7.2.5.jar;lib\io-7.2.5.jar;lib\kernel-7.2.5.jar;lib\layout-7.2.5.jar
set CP=%CP%;lib\slf4j-api-1.7.36.jar;lib\slf4j-simple-1.7.36.jar

javac -encoding UTF-8 -d build\classes -cp "%CP%" -sourcepath src src\ts\*.java src\ts\dao\*.java src\ts\database\*.java src\ts\model\*.java src\ts\service\*.java src\ts\util\*.java

if errorlevel 1 (
    echo [ERROR] Compilation failed
    pause
    exit /b 1
)
echo [OK] Code compiled successfully

echo.
echo Step 5: Copying resources...
xcopy /s /y src\ts\*.png build\classes\ts\ >nul 2>&1
xcopy /s /y src\ts\*.form build\classes\ts\ >nul 2>&1
xcopy /s /y src\ts\fonts build\classes\ts\fonts\ >nul 2>&1
echo [OK] Resources copied

echo.
echo Step 6: Creating JAR file...

REM إنشاء Manifest
echo Manifest-Version: 1.0 > manifest.tmp
echo Main-Class: ts.TS >> manifest.tmp
echo Class-Path: lib/h2-2.4.240.jar lib/mysql-connector-j-8.0.33.jar lib/poi-5.2.5.jar lib/poi-ooxml-5.2.5.jar lib/commons-collections4-4.4.jar lib/commons-compress-1.26.0.jar lib/commons-io-2.15.1.jar lib/commons-codec-1.16.0.jar lib/commons-math3-3.6.1.jar lib/SparseBitSet-1.3.jar lib/log4j-api-2.21.1.jar lib/poi-ooxml-lite-5.2.5.jar lib/xmlbeans-5.1.1.jar lib/commons-7.2.5.jar lib/io-7.2.5.jar lib/kernel-7.2.5.jar lib/layout-7.2.5.jar lib/slf4j-api-1.7.36.jar lib/slf4j-simple-1.7.36.jar >> manifest.tmp
echo. >> manifest.tmp

jar cfm dist\TS.jar manifest.tmp -C build\classes .

if errorlevel 1 (
    echo [ERROR] Failed to create JAR
    del manifest.tmp
    pause
    exit /b 1
)

del manifest.tmp
echo [OK] JAR created: dist\TS.jar

echo.
echo ========================================
echo      BUILD SUCCESSFUL!
echo ========================================
echo.
echo Output file: dist\TS.jar
echo.
echo Next steps:
echo 1. Run application: run.bat
echo 2. Create deployment package: create_deployment_package.bat
echo.
pause

