package ts;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import ts.FontManager;

public class TailorShopDashboard extends javax.swing.JFrame {

    public TailorShopDashboard() {
        this.setUndecorated(true);
        initComponents();
        applyFullScreen();
        setupDashboard();
        getContentPane().setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        minimizeButton = new javax.swing.JLabel();
        userInfoLabel = new javax.swing.JLabel();
        logoutButton = new javax.swing.JLabel();
        sidebarPanel = new javax.swing.JPanel();
        contentPanel = new javax.swing.JPanel();
        customersPanel = new javax.swing.JPanel();
        invoicesPanel = new javax.swing.JPanel();
        reportsPanel = new javax.swing.JPanel();
        
        customersButton = new javax.swing.JButton();
        invoicesButton = new javax.swing.JButton();
        reportsButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tailor Shop Management System");

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setPreferredSize(new java.awt.Dimension(1400, 900));
        mainPanel.setLayout(new java.awt.BorderLayout());

        headerPanel.setBackground(new java.awt.Color(0, 153, 204));
        headerPanel.setPreferredSize(new java.awt.Dimension(1400, 60));

        titleLabel.setFont(FontManager.getMontserrat("ExtraBold", 24f));
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("إدارة الحكمة - نظام إدارة محل الخياطة");

        minimizeButton.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 18));
        minimizeButton.setForeground(new java.awt.Color(255, 255, 255));
        minimizeButton.setText("−");
        minimizeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        minimizeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeButtonMouseClicked(evt);
            }
        });

        userInfoLabel.setFont(FontManager.getMontserrat("Medium", 14f));
        userInfoLabel.setForeground(new java.awt.Color(255, 255, 255));
        userInfoLabel.setText("مرحباً، ");

        logoutButton.setFont(FontManager.getMontserrat("Medium", 14f));
        logoutButton.setForeground(new java.awt.Color(255, 255, 255));
        logoutButton.setText("تسجيل الخروج");
        logoutButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(titleLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(userInfoLabel)
                .addGap(20, 20, 20)
                .addComponent(logoutButton)
                .addGap(10, 10, 10)
                .addComponent(minimizeButton)
                .addGap(20, 20, 20))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(minimizeButton)
                    .addComponent(userInfoLabel)
                    .addComponent(logoutButton))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        mainPanel.add(headerPanel, java.awt.BorderLayout.NORTH);

        sidebarPanel.setBackground(new java.awt.Color(25, 118, 210));
        sidebarPanel.setPreferredSize(new java.awt.Dimension(260, 0));
        sidebarPanel.setLayout(new java.awt.BorderLayout());
        sidebarPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20));

        JPanel sidebarButtonsPanel = new JPanel();
        sidebarButtonsPanel.setLayout(new java.awt.GridLayout(0, 1, 0, 15));
        sidebarButtonsPanel.setBackground(new java.awt.Color(25, 118, 210));
        sidebarButtonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        customersButton.setText("العملاء");
        customersButton.setFont(FontManager.getMontserrat("Medium", 16f));
        customersButton.setForeground(new java.awt.Color(255, 255, 255));
        customersButton.setBackground(new java.awt.Color(25, 118, 210));
        customersButton.setBorder(BorderFactory.createEmptyBorder(18, 25, 18, 25));
        customersButton.setFocusPainted(false);
        customersButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        customersButton.setIcon(createIcon("👥"));
        customersButton.setHorizontalAlignment(SwingConstants.LEFT);

        invoicesButton.setText("الفواتير");
        invoicesButton.setFont(FontManager.getMontserrat("Medium", 16f));
        invoicesButton.setForeground(new java.awt.Color(255, 255, 255));
        invoicesButton.setBackground(new java.awt.Color(25, 118, 210));
        invoicesButton.setBorder(BorderFactory.createEmptyBorder(18, 25, 18, 25));
        invoicesButton.setFocusPainted(false);
        invoicesButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        invoicesButton.setIcon(createIcon("📄"));
        invoicesButton.setHorizontalAlignment(SwingConstants.LEFT);

        reportsButton.setText("التقارير");
        reportsButton.setFont(FontManager.getMontserrat("Medium", 16f));
        reportsButton.setForeground(new java.awt.Color(255, 255, 255));
        reportsButton.setBackground(new java.awt.Color(25, 118, 210));
        reportsButton.setBorder(BorderFactory.createEmptyBorder(18, 25, 18, 25));
        reportsButton.setFocusPainted(false);
        reportsButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reportsButton.setIcon(createIcon("📊"));
        reportsButton.setHorizontalAlignment(SwingConstants.LEFT);

        sidebarButtonsPanel.add(customersButton);
        sidebarButtonsPanel.add(invoicesButton);
        sidebarButtonsPanel.add(reportsButton);

        sidebarPanel.add(sidebarButtonsPanel, java.awt.BorderLayout.CENTER);

        contentPanel.setBackground(new java.awt.Color(240, 240, 240));
        contentPanel.setLayout(new java.awt.BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        customersPanel.setBackground(new java.awt.Color(240, 240, 240));
        customersPanel.setLayout(new java.awt.BorderLayout());

        invoicesPanel.setBackground(new java.awt.Color(240, 240, 240));
        invoicesPanel.setLayout(new java.awt.BorderLayout());

        reportsPanel.setBackground(new java.awt.Color(240, 240, 240));
        reportsPanel.setLayout(new java.awt.BorderLayout());

        JPanel bodyPanel = new JPanel(new java.awt.BorderLayout());
        bodyPanel.add(contentPanel, java.awt.BorderLayout.CENTER);
        bodyPanel.add(sidebarPanel, java.awt.BorderLayout.EAST);
        mainPanel.add(bodyPanel, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    private void minimizeButtonMouseClicked(java.awt.event.MouseEvent evt) {
        this.setState(TailorShopDashboard.ICONIFIED);
    }

    private void logoutButtonMouseClicked(java.awt.event.MouseEvent evt) {
        this.dispose();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login1().setVisible(true);
            }
        });
    }

    private void applyFullScreen() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize);
        setLocationRelativeTo(null);
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    }

    private void setupDashboard() {
        setupCustomersPanel();
        setupInvoicesPanel();
        setupReportsPanel();
        setupButtonListeners();
        showPanel(customersPanel);
        customersButton.setBackground(new java.awt.Color(21, 101, 192));
    }
    
    private void setupCustomersPanel() {
        JPanel customersContent = new JPanel();
        customersContent.setLayout(new BorderLayout());
        customersContent.setBackground(new Color(245, 247, 250));
        
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        JLabel customersTitle = new JLabel("إدارة العملاء");
        customersTitle.setFont(FontManager.getMontserrat("ExtraBold", 22f));
        customersTitle.setForeground(new Color(25, 118, 210));
        customersTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 25, 0));
        customersTitle.setHorizontalAlignment(SwingConstants.RIGHT);
        
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonsPanel.setBackground(Color.WHITE);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JButton addCustomerBtn = createStyledButton("أضافة عميل جديد");
        JButton addPaymentBtn = createStyledButton("إضافة دفعة");
        
        buttonsPanel.add(addCustomerBtn);
        buttonsPanel.add(addPaymentBtn);
        
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        searchPanel.setBackground(Color.WHITE);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JTextField searchField = new JTextField(25);
        searchField.setFont(FontManager.getMontserrat("Medium", 15f));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 118, 210), 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        searchField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        searchField.setPreferredSize(new Dimension(320, 40));
        searchField.setBackground(new Color(255, 255, 255));
        
        JLabel searchLabel = new JLabel("بحث:");
        searchLabel.setFont(FontManager.getMontserrat("Bold", 16f));
        searchLabel.setForeground(new Color(25, 118, 210));
        
        searchPanel.add(searchField);
        searchPanel.add(searchLabel);
        
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        
        String[] columnNames = {"تاريخ الاستحقاق", "المتبقي", "عدد الطلبات", "رقم الهاتف", "اسم العميل", "customer_id"};
        Object[][] data = {};
        
        javax.swing.table.DefaultTableModel customersModel = new javax.swing.table.DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable customersTable = new JTable(customersModel);
        this.customersTableRef = customersTable;
        customersTable.setFont(FontManager.getMontserrat("Medium", 15f));
        customersTable.setRowHeight(40);
        customersTable.setBackground(Color.WHITE);
        customersTable.setGridColor(new Color(230, 230, 230));
        customersTable.setShowGrid(true);
        customersTable.setSelectionBackground(new Color(25, 118, 210, 20));
        customersTable.setSelectionForeground(new Color(25, 118, 210));
        
        customersTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                return this;
            }
        });
        
        customersTable.getTableHeader().setBackground(new Color(25, 118, 210));
        customersTable.getTableHeader().setForeground(Color.WHITE);
        customersTable.getTableHeader().setFont(FontManager.getMontserrat("Bold", 15f));
        customersTable.getTableHeader().setReorderingAllowed(false);
        customersTable.getTableHeader().setPreferredSize(new Dimension(0, 45));
        
        customersTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        customersTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        customersTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        customersTable.getColumnModel().getColumn(3).setPreferredWidth(120);
        customersTable.getColumnModel().getColumn(4).setPreferredWidth(150);
        // Hide customer_id column
        customersTable.getColumnModel().getColumn(5).setMinWidth(0);
        customersTable.getColumnModel().getColumn(5).setMaxWidth(0);
        customersTable.getColumnModel().getColumn(5).setWidth(0);
        
        JScrollPane scrollPane = new JScrollPane(customersTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollPane.setPreferredSize(new Dimension(1100, 420));
        scrollPane.setBackground(Color.WHITE);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        mainContentPanel.add(customersTitle, BorderLayout.NORTH);
        mainContentPanel.add(buttonsPanel, BorderLayout.CENTER);
        mainContentPanel.add(searchPanel, BorderLayout.SOUTH);
        
        customersContent.add(mainContentPanel, BorderLayout.NORTH);
        customersContent.add(tablePanel, BorderLayout.CENTER);
        
        addCustomerBtn.addActionListener(e -> {
            showAddCustomerDialog();
            loadCustomersData(customersTable);
        });
        addPaymentBtn.addActionListener(e -> {
            int selectedRow = customersTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, 
                    "برجاء اختيار عميل من الجدول", 
                    "تنبيه", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Get customer ID from the selected row
            Object customerIdObj = customersTable.getValueAt(selectedRow, 5);
            if (customerIdObj == null) {
                JOptionPane.showMessageDialog(this, 
                    "خطأ في الحصول على بيانات العميل", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int customerId = (Integer) customerIdObj;
            showAddPaymentDialog(customerId);
            loadCustomersData(customersTable);
        });
        
        // Add search functionality
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                searchCustomers(customersTable, searchField.getText());
            }
        });
        
        // Load initial data
        loadCustomersData(customersTable);
        
        customersPanel.add(customersContent);
    }
    
    private void setupInvoicesPanel() {
        JPanel invoicesContent = new JPanel();
        invoicesContent.setLayout(new BorderLayout());
        invoicesContent.setBackground(new Color(245, 247, 250));
        
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        JLabel invoicesTitle = new JLabel("إدارة الفواتير");
        invoicesTitle.setFont(FontManager.getMontserrat("ExtraBold", 22f));
        invoicesTitle.setForeground(new Color(25, 118, 210));
        invoicesTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 25, 0));
        invoicesTitle.setHorizontalAlignment(SwingConstants.RIGHT);
        
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonsPanel.setBackground(Color.WHITE);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JButton newInvoiceBtn = createStyledButton("فاتورة جديدة");
        JButton deliveryBtn = createStyledButton("تسليم");
        JButton completeInvoiceBtn = createStyledButton("إكمال الفاتورة");
        
        buttonsPanel.add(newInvoiceBtn);
        buttonsPanel.add(deliveryBtn);
        buttonsPanel.add(completeInvoiceBtn);
        
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        searchPanel.setBackground(Color.WHITE);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JTextField searchField = new JTextField(25);
        searchField.setFont(FontManager.getMontserrat("Medium", 15f));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 118, 210), 1),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        searchField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        searchField.setPreferredSize(new Dimension(320, 40));
        searchField.setBackground(new Color(255, 255, 255));
        
        JLabel searchLabel = new JLabel("بحث:");
        searchLabel.setFont(FontManager.getMontserrat("Bold", 16f));
        searchLabel.setForeground(new Color(25, 118, 210));
        
        searchPanel.add(searchField);
        searchPanel.add(searchLabel);
        
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        
        String[] columnNames = {"الحالة", "التسليم", "تاريخ التسليم", "الباقي", "المدفوع", "الإجمالي", "اسم العميل", "رقم الفاتورة", "invoice_id"};
        Object[][] data = {};
        
        javax.swing.table.DefaultTableModel invoicesModel = new javax.swing.table.DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable invoicesTable = new JTable(invoicesModel);
        this.invoicesTableRef = invoicesTable;
        invoicesTable.setFont(FontManager.getMontserrat("Medium", 15f));
        invoicesTable.setRowHeight(40);
        invoicesTable.setBackground(Color.WHITE);
        invoicesTable.setGridColor(new Color(230, 230, 230));
        invoicesTable.setShowGrid(true);
        invoicesTable.setSelectionBackground(new Color(25, 118, 210, 20));
        invoicesTable.setSelectionForeground(new Color(25, 118, 210));
        
        invoicesTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);
                return this;
            }
        });
        
        invoicesTable.getTableHeader().setBackground(new Color(25, 118, 210));
        invoicesTable.getTableHeader().setForeground(Color.WHITE);
        invoicesTable.getTableHeader().setFont(FontManager.getMontserrat("Bold", 15f));
        invoicesTable.getTableHeader().setReorderingAllowed(false);
        invoicesTable.getTableHeader().setPreferredSize(new Dimension(0, 45));
        
        invoicesTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        invoicesTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        invoicesTable.getColumnModel().getColumn(2).setPreferredWidth(120);
        invoicesTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        invoicesTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        invoicesTable.getColumnModel().getColumn(5).setPreferredWidth(100);
        invoicesTable.getColumnModel().getColumn(6).setPreferredWidth(150);
        invoicesTable.getColumnModel().getColumn(7).setPreferredWidth(120);
        // Hide invoice_id column
        invoicesTable.getColumnModel().getColumn(8).setMinWidth(0);
        invoicesTable.getColumnModel().getColumn(8).setMaxWidth(0);
        invoicesTable.getColumnModel().getColumn(8).setWidth(0);
        
        JScrollPane scrollPane = new JScrollPane(invoicesTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollPane.setPreferredSize(new Dimension(1100, 420));
        scrollPane.setBackground(Color.WHITE);
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        mainContentPanel.add(invoicesTitle, BorderLayout.NORTH);
        mainContentPanel.add(buttonsPanel, BorderLayout.CENTER);
        mainContentPanel.add(searchPanel, BorderLayout.SOUTH);
        
        invoicesContent.add(mainContentPanel, BorderLayout.NORTH);
        invoicesContent.add(tablePanel, BorderLayout.CENTER);
        
        newInvoiceBtn.addActionListener(e -> {
            showCreateInvoiceDialog();
            loadInvoicesData(invoicesTable);
        });
        
        deliveryBtn.addActionListener(e -> {
            int selectedRow = invoicesTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, 
                    "برجاء اختيار فاتورة من الجدول", 
                    "تنبيه", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Get invoice ID from the selected row
            Object invoiceIdObj = invoicesTable.getValueAt(selectedRow, 8);
            if (invoiceIdObj == null) {
                JOptionPane.showMessageDialog(this, 
                    "خطأ في الحصول على بيانات الفاتورة", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int invoiceId = (Integer) invoiceIdObj;
            
            // Get invoice details
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            ts.model.Invoice invoice = invoiceService.getInvoiceById(invoiceId);
            
            if (invoice == null) {
                JOptionPane.showMessageDialog(this, 
                    "لم يتم العثور على الفاتورة", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if invoice is completed
            if (!"مكتمل".equals(invoice.getStatus())) {
                JOptionPane.showMessageDialog(this, 
                    "يجب إكمال الفاتورة أولاً قبل التسليم", 
                    "تنبيه", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Check if already delivered
            if ("تم التسليم".equals(invoice.getDeliveryStatus())) {
                JOptionPane.showMessageDialog(this, 
                    "تم تسليم الفاتورة مسبقاً", 
                    "تنبيه", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Show delivery dialog
            DeliveryPaymentDialog deliveryDialog = new DeliveryPaymentDialog(
                (java.awt.Frame) SwingUtilities.getWindowAncestor(this), 
                true, 
                invoice
            );
            deliveryDialog.setVisible(true);
            
            // Refresh table if delivery was completed
            if (deliveryDialog.isDeliveryCompleted()) {
                loadInvoicesData(invoicesTable);
            }
        });
        
        completeInvoiceBtn.addActionListener(e -> {
            int selectedRow = invoicesTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this, 
                    "برجاء اختيار فاتورة من الجدول", 
                    "تنبيه", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Get invoice ID from the selected row
            Object invoiceIdObj = invoicesTable.getValueAt(selectedRow, 8);
            if (invoiceIdObj == null) {
                JOptionPane.showMessageDialog(this, 
                    "خطأ في الحصول على بيانات الفاتورة", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int invoiceId = (Integer) invoiceIdObj;
            
            // Get current status
            String currentStatus = (String) invoicesTable.getValueAt(selectedRow, 0);
            if ("مكتمل".equals(currentStatus)) {
                JOptionPane.showMessageDialog(this, 
                    "الفاتورة مكتملة بالفعل", 
                    "تنبيه", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Confirm action
            int confirm = JOptionPane.showConfirmDialog(this, 
                "هل تريد تغيير حالة الفاتورة إلى مكتمل؟", 
                "تأكيد", 
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = completeInvoice(invoiceId);
                if (success) {
                    // Refresh the table data
                    if (invoicesTableRef != null) {
                        loadInvoicesData(invoicesTableRef);
                    } else {
                        loadInvoicesData(invoicesTable);
                    }
                    JOptionPane.showMessageDialog(this, 
                        "تم تغيير حالة الفاتورة إلى مكتمل بنجاح", 
                        "نجح", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        // Add search functionality
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                searchInvoices(invoicesTable, searchField.getText());
            }
        });
        
        // Load initial data
        loadInvoicesData(invoicesTable);
        
        invoicesPanel.add(invoicesContent);
    }
    
    private void setupReportsPanel() {
        JPanel reportsContent = new JPanel();
        reportsContent.setLayout(new BorderLayout());
        reportsContent.setBackground(new Color(240, 240, 240));
        
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        
        JLabel reportsTitle = new JLabel("التقارير والإحصائيات");
        reportsTitle.setFont(FontManager.getMontserrat("ExtraBold", 20f));
        reportsTitle.setForeground(new Color(0, 0, 0));
        reportsTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        reportsTitle.setHorizontalAlignment(SwingConstants.CENTER);
        
        JPanel reportsButtonsPanel = new JPanel();
        reportsButtonsPanel.setLayout(new GridLayout(1, 2, 15, 15));
        reportsButtonsPanel.setBackground(Color.WHITE);
        
        JButton customersReportBtn = createReportButton("تقرير العملاء المتبقي عليهم", "👥");
        JButton detailedInvoiceBtn = createReportButton("تقرير تفصيلي للفواتير", "📄");
        
        reportsButtonsPanel.add(customersReportBtn);
        reportsButtonsPanel.add(detailedInvoiceBtn);
        
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(new GridLayout(1, 4, 15, 15));
        statsPanel.setBackground(Color.WHITE);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));
        
        JPanel totalCustomersCard = createStatCard("25", "إجمالي العملاء");
        JPanel activeInvoicesCard = createStatCard("12", "الفواتير النشطة");
        JPanel dailyRevenueCard = createStatCard("2500 جنيه", "الإيرادات اليوم");
        JPanel pendingAmountCard = createStatCard("1800 جنيه", "المتبقى تحصيله");
        
        // Store references for refresh
        this.totalCustomersCardRef = totalCustomersCard;
        this.activeInvoicesCardRef = activeInvoicesCard;
        this.dailyRevenueCardRef = dailyRevenueCard;
        this.pendingAmountCardRef = pendingAmountCard;
        
        statsPanel.add(totalCustomersCard);
        statsPanel.add(activeInvoicesCard);
        statsPanel.add(dailyRevenueCard);
        statsPanel.add(pendingAmountCard);
        
        mainContentPanel.add(reportsTitle, BorderLayout.NORTH);
        mainContentPanel.add(reportsButtonsPanel, BorderLayout.CENTER);
        mainContentPanel.add(statsPanel, BorderLayout.SOUTH);
        
        reportsContent.add(mainContentPanel, BorderLayout.CENTER);
        
        customersReportBtn.addActionListener(e -> showCustomersReportOptions());
        detailedInvoiceBtn.addActionListener(e -> showDetailedInvoiceReport());
        
        // Load dashboard statistics
        loadDashboardStatistics(totalCustomersCard, activeInvoicesCard, dailyRevenueCard, pendingAmountCard);
        
        reportsPanel.add(reportsContent);
    }
    
    
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(FontManager.getMontserrat("Medium", 16f));
        button.setBackground(new Color(25, 118, 210)); // Updated blue color
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 118, 210), 1),
            BorderFactory.createEmptyBorder(15, 35, 15, 35)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(230, 50));
        button.setMinimumSize(new Dimension(200, 50));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(21, 101, 192));
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(21, 101, 192), 1),
                    BorderFactory.createEmptyBorder(15, 35, 15, 35)
                ));
            }
            
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(25, 118, 210));
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(25, 118, 210), 1),
                    BorderFactory.createEmptyBorder(15, 35, 15, 35)
                ));
            }
        });
        
        return button;
    }
    
    private Icon createIcon(String emoji) {
        JLabel label = new JLabel(emoji);
        label.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        label.setForeground(Color.WHITE);
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                label.paint(g);
            }
            
            @Override
            public int getIconWidth() {
                return 20;
            }
            
            @Override
            public int getIconHeight() {
                return 20;
            }
        };
    }
    
    private JButton createReportButton(String text, String emoji) {
        JButton button = new JButton(text);
        button.setFont(FontManager.getMontserrat("Medium", 16f));
        button.setBackground(new Color(25, 118, 210)); // Updated blue color
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(220, 55));
        button.setMinimumSize(new Dimension(200, 50));
        button.setIcon(createIcon(emoji));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(21, 101, 192));
            }
            
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(25, 118, 210));
            }
        });
        
        return button;
    }
    
    private JPanel createStatCard(String value, String title) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(25, 118, 210), 2),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(FontManager.getMontserrat("ExtraBold", 24f));
        valueLabel.setForeground(new Color(25, 118, 210));
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FontManager.getMontserrat("Medium", 14f));
        titleLabel.setForeground(new Color(100, 100, 100));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(titleLabel, BorderLayout.SOUTH);
        
        return card;
    }
    
    private void showAddCustomerDialog() {
        CustomerDialog dialog = new CustomerDialog(this, true);
        dialog.setVisible(true);
    }
    
    private void showCreateInvoiceDialog() {
        InvoiceDialog dialog = new InvoiceDialog(this, true);
        dialog.setVisible(true);
    }
    
    private void showAddPaymentDialog(int customerId) {
        PaymentDialog paymentDialog = new PaymentDialog(this, true, customerId);
        paymentDialog.setVisible(true);
    }
    
    private void showDetailedInvoiceReport() {
        InvoiceReportDialog dialog = new InvoiceReportDialog(this, true);
        dialog.setVisible(true);
    }
    
    private void showCustomersReportOptions() {
        // Show options dialog for viewing or printing report
        Object[] options = {"عرض التقرير", "طباعة PDF", "إلغاء"};
        int choice = JOptionPane.showOptionDialog(this,
            "اختر طريقة عرض التقرير:",
            "تقرير العملاء المتبقي عليهم",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        if (choice == 0) {
            // Show dialog
            CustomerReportDialog dialog = new CustomerReportDialog(this, true);
            dialog.setVisible(true);
        } else if (choice == 1) {
            // Generate PDF
            generatePendingCustomersPDF();
        }
    }
    
    private void generatePendingCustomersPDF() {
        try {
            ts.util.InvoiceExcelGenerator.generateAndOpenPendingCustomersReportExcel();
            JOptionPane.showMessageDialog(this,
                "تم إنشاء تقرير Excel بنجاح",
                "نجاح",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            System.err.println("خطأ في إنشاء تقرير Excel: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "خطأ في إنشاء تقرير Excel: " + e.getMessage(),
                "خطأ",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean completeInvoice(int invoiceId) {
        try {
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            ts.model.Invoice invoice = invoiceService.getInvoiceById(invoiceId);
            
            if (invoice == null) {
                JOptionPane.showMessageDialog(this, 
                    "الفاتورة غير موجودة", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Change status to "مكتمل" only (don't change financial amounts)
            // إكمال الفاتورة يعني أن العمل اكتمل، لكن العميل قد يكون ما زال عليه فلوس
            invoice.setStatus("مكتمل");
            
            // Update invoice (only status will be updated, amounts remain unchanged)
            boolean success = invoiceService.updateInvoice(invoice);
            
            if (!success) {
                JOptionPane.showMessageDialog(this, 
                    "فشل في تغيير حالة الفاتورة", 
                    "خطأ", 
                    JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        } catch (Exception e) {
            System.err.println("خطأ في إكمال الفاتورة: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "خطأ في الاتصال بقاعدة البيانات: " + e.getMessage(), 
                "خطأ", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private void setupButtonListeners() {
        customersButton.addActionListener(e -> {
            resetButtonColors();
            customersButton.setBackground(new java.awt.Color(21, 101, 192));
            // Refresh customers data before showing panel
            if (customersTableRef != null) {
                loadCustomersData(customersTableRef);
            }
            showPanel(customersPanel);
        });
        
        invoicesButton.addActionListener(e -> {
            resetButtonColors();
            invoicesButton.setBackground(new java.awt.Color(21, 101, 192)); // Active color
            // Refresh invoices data before showing panel
            if (invoicesTableRef != null) {
                loadInvoicesData(invoicesTableRef);
            }
            showPanel(invoicesPanel);
        });
        
        reportsButton.addActionListener(e -> {
            resetButtonColors();
            reportsButton.setBackground(new java.awt.Color(21, 101, 192)); // Active color
            // Refresh reports data before showing panel
            refreshReportsPanel();
            showPanel(reportsPanel);
        });
        
    }
    
    private void resetButtonColors() {
        customersButton.setBackground(new java.awt.Color(25, 118, 210));
        invoicesButton.setBackground(new java.awt.Color(25, 118, 210));
        reportsButton.setBackground(new java.awt.Color(25, 118, 210));
    }
    
    private void showPanel(JPanel panel) {
        contentPanel.removeAll();
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private javax.swing.JPanel contentPanel;
    private javax.swing.JPanel customersPanel;
    private javax.swing.JButton customersButton;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JPanel invoicesPanel;
    private javax.swing.JButton invoicesButton;
    private javax.swing.JLabel logoutButton;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JLabel minimizeButton;
    private javax.swing.JPanel reportsPanel;
    private javax.swing.JButton reportsButton;
    private javax.swing.JPanel sidebarPanel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel userInfoLabel;
    
    // Table references for data refresh
    private JTable customersTableRef;
    private JTable invoicesTableRef;
    
    // Reports panel card references for data refresh
    private JPanel totalCustomersCardRef;
    private JPanel activeInvoicesCardRef;
    private JPanel dailyRevenueCardRef;
    private JPanel pendingAmountCardRef;
    
    // Backend integration methods
    private void loadCustomersData(JTable table) {
        try {
            ts.service.ReportService reportService = new ts.service.ReportService();
            java.util.List<java.util.Map<String, Object>> customers = reportService.getAllCustomersSummary();
            
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) table.getModel();
            model.setRowCount(0);
            
            for (java.util.Map<String, Object> customer : customers) {
                Object[] row = {
                    customer.get("delivery_date"),
                    customer.get("total_remaining") + " جنيه",
                    customer.get("order_count"),
                    customer.get("phone"),
                    customer.get("name"),
                    customer.get("customer_id")  // Add customer_id as hidden column
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("خطأ في تحميل بيانات العملاء: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void searchCustomers(JTable table, String searchTerm) {
        try {
            ts.service.CustomerService customerService = new ts.service.CustomerService();
            java.util.List<ts.model.Customer> customers = customerService.searchCustomers(searchTerm);
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) table.getModel();
            model.setRowCount(0);
            
            for (ts.model.Customer customer : customers) {
                java.util.List<ts.model.Invoice> invoices = invoiceService.getInvoicesByCustomerId(customer.getCustomerId());
                
                java.math.BigDecimal totalRemaining = invoices.stream()
                    .map(ts.model.Invoice::getRemainingAmount)
                    .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add);
                
                Object[] row = {
                    customer.getDeliveryDate(),
                    totalRemaining + " جنيه",
                    invoices.size(),
                    customer.getPhone(),
                    customer.getName(),
                    customer.getCustomerId()  // Add customer_id as hidden column
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("خطأ في البحث عن العملاء: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadInvoicesData(JTable table) {
        try {
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            java.util.List<ts.model.Invoice> invoices = invoiceService.getAllInvoices();
            
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) table.getModel();
            model.setRowCount(0);
            
            for (ts.model.Invoice invoice : invoices) {
                Object[] row = {
                    invoice.getStatus(),
                    invoice.getDeliveryStatus(),
                    invoice.getDeliveryDate(),
                    invoice.getRemainingAmount() + " جنيه",
                    invoice.getPaidAmount() + " جنيه",
                    invoice.getTotalAmount() + " جنيه",
                    invoice.getCustomerName(),
                    invoice.getInvoiceNumber(),
                    invoice.getInvoiceId()  // Add invoice_id as hidden column
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("خطأ في تحميل بيانات الفواتير: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void searchInvoices(JTable table, String searchTerm) {
        try {
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            java.util.List<ts.model.Invoice> invoices = invoiceService.searchInvoices(searchTerm);
            
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) table.getModel();
            model.setRowCount(0);
            
            for (ts.model.Invoice invoice : invoices) {
                Object[] row = {
                    invoice.getStatus(),
                    invoice.getDeliveryStatus(),
                    invoice.getDeliveryDate(),
                    invoice.getRemainingAmount() + " جنيه",
                    invoice.getPaidAmount() + " جنيه",
                    invoice.getTotalAmount() + " جنيه",
                    invoice.getCustomerName(),
                    invoice.getInvoiceNumber(),
                    invoice.getInvoiceId()  // Add invoice_id as hidden column
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("خطأ في البحث عن الفواتير: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadDashboardStatistics(JPanel totalCustomersCard, JPanel activeInvoicesCard, JPanel dailyRevenueCard, JPanel pendingAmountCard) {
        try {
            ts.service.ReportService reportService = new ts.service.ReportService();
            java.util.Map<String, Object> stats = reportService.getDashboardStatistics();
            
            // Update cards
            updateStatCard(totalCustomersCard, stats.get("total_customers").toString());
            updateStatCard(activeInvoicesCard, stats.get("active_invoices").toString());
            updateStatCard(dailyRevenueCard, stats.get("today_revenue") + " جنيه");
            updateStatCard(pendingAmountCard, stats.get("total_remaining") + " جنيه");
        } catch (Exception e) {
            System.err.println("خطأ في تحميل الإحصائيات: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void refreshReportsPanel() {
        // Update statistics cards using stored references
        if (totalCustomersCardRef != null && activeInvoicesCardRef != null && 
            dailyRevenueCardRef != null && pendingAmountCardRef != null) {
            loadDashboardStatistics(
                totalCustomersCardRef,
                activeInvoicesCardRef,
                dailyRevenueCardRef,
                pendingAmountCardRef
            );
        }
    }
    
    private void updateStatCard(JPanel card, String value) {
        for (java.awt.Component comp : card.getComponents()) {
            if (comp instanceof JLabel) {
                JLabel label = (JLabel) comp;
                if (label.getHorizontalAlignment() == SwingConstants.CENTER && 
                    label.getFont().getSize() >= 20) {
                    label.setText(value);
                    break;
                }
            }
        }
    }
}