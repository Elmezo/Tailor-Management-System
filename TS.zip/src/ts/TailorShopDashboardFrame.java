package ts;

import java.awt.ComponentOrientation;
import javax.swing.JFrame;

/**
 * TailorShopDashboard Frame that wraps the TailorShopDashboardPanel
 * This is a thin JFrame wrapper around the TailorShopDashboardPanel
 */
public class TailorShopDashboardFrame extends javax.swing.JFrame {
    
    private TailorShopDashboardPanel dashboardPanel;
    
    /**
     * Creates new form TailorShopDashboardFrame
     */
    public TailorShopDashboardFrame() {
        initComponents();
        setupFrame();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        dashboardPanel = new TailorShopDashboardPanel();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("نظام إدارة محل الخياطة");
        setUndecorated(true);
        
        // Set the dashboard panel as the content pane
        setContentPane(dashboardPanel);
        
        pack();
        setLocationRelativeTo(null);
    }
    
    /**
     * Setup frame properties
     */
    private void setupFrame() {
        // Set component orientation for RTL support
        getContentPane().setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        // Center the frame on screen
        setLocationRelativeTo(null);
    }
    
    /**
     * Get the dashboard panel
     * @return the dashboard panel
     */
    public TailorShopDashboardPanel getDashboardPanel() {
        return dashboardPanel;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TailorShopDashboardFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TailorShopDashboardFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TailorShopDashboardFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TailorShopDashboardFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TailorShopDashboardFrame().setVisible(true);
            }
        });
    }
} 