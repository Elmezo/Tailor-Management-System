package ts;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.event.*;
import ts.FontManager;
import java.util.List;
import java.math.BigDecimal;

/**
 * Dialog to show detailed invoices for a specific customer
 * @author future
 */
public class CustomerInvoicesDetailDialog extends javax.swing.JDialog {
    
    private int customerId;
    private String customerName;

    /**
     * Creates new form CustomerInvoicesDetailDialog
     */
    public CustomerInvoicesDetailDialog(java.awt.Frame parent, boolean modal, int customerId, String customerName) {
        super(parent, modal);
        this.customerId = customerId;
        this.customerName = customerName;
        initComponents();
        setupDialog();
        loadInvoicesData();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        closeButton = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        invoicesTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("تفاصيل فواتير العميل");
        setModal(true);
        setResizable(false);

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setPreferredSize(new java.awt.Dimension(700, 500));
        mainPanel.setLayout(null);

        headerPanel.setBackground(new java.awt.Color(25, 118, 210));
        headerPanel.setPreferredSize(new java.awt.Dimension(700, 40));

        FontManager.applyMontserrat(titleLabel, "ExtraBold", 18f);
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("فواتير العميل: " + customerName);
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        titleLabel.setComponentOrientation(java.awt.ComponentOrientation.RIGHT_TO_LEFT);

        closeButton.setFont(new java.awt.Font("Arial", 1, 18));
        closeButton.setForeground(new java.awt.Color(255, 255, 255));
        closeButton.setText("✕");
        closeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        closeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(closeButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(titleLabel)
                .addGap(20, 20, 20))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(closeButton))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        mainPanel.add(headerPanel);
        headerPanel.setBounds(0, 0, 700, 40);

        contentPanel.setBackground(new java.awt.Color(255, 255, 255));
        contentPanel.setLayout(null);

        // Setup table
        invoicesTable.setFont(FontManager.getMontserrat("Medium", 14f));
        invoicesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "رقم الفاتورة", "الباقي", "تاريخ الاستلام"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        invoicesTable.setRowHeight(30);
        invoicesTable.setShowGrid(true);
        invoicesTable.setShowVerticalLines(true);
        invoicesTable.setShowHorizontalLines(true);
        invoicesTable.getTableHeader().setFont(FontManager.getMontserrat("Bold", 14f));
        invoicesTable.getTableHeader().setBackground(new java.awt.Color(25, 118, 210));
        invoicesTable.getTableHeader().setForeground(new java.awt.Color(255, 255, 255));
        invoicesTable.getTableHeader().setReorderingAllowed(false);
        
        // Center align all cells
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        invoicesTable.setDefaultRenderer(Object.class, centerRenderer);
        
        // Center align header
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) invoicesTable.getTableHeader().getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        scrollPane.setViewportView(invoicesTable);

        // Position components
        contentPanel.add(scrollPane);
        scrollPane.setBounds(30, 20, 640, 400);

        mainPanel.add(contentPanel);
        contentPanel.setBounds(0, 40, 700, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }

    private void closeButtonMouseClicked(java.awt.event.MouseEvent evt) {
        dispose();
    }

    private void setupDialog() {
        // Set dialog properties
        setLocationRelativeTo(null);
        getContentPane().setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        // Set RTL for table
        invoicesTable.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        // Set RTL for labels
        titleLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
    }
    
    private void loadInvoicesData() {
        try {
            ts.service.InvoiceService invoiceService = new ts.service.InvoiceService();
            List<ts.model.Invoice> allInvoices = invoiceService.getInvoicesByCustomerId(customerId);
            
            // Filter invoices with remaining amount > 0
            List<ts.model.Invoice> unpaidInvoices = allInvoices.stream()
                .filter(invoice -> invoice.getRemainingAmount().compareTo(BigDecimal.ZERO) > 0)
                .collect(java.util.stream.Collectors.toList());
            
            // Update table
            javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) invoicesTable.getModel();
            model.setRowCount(0); // Clear existing rows
            
            if (unpaidInvoices.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "لا توجد فواتير غير مدفوعة لهذا العميل", 
                    "معلومة", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            for (ts.model.Invoice invoice : unpaidInvoices) {
                Object[] row = {
                    invoice.getInvoiceNumber(),
                    invoice.getRemainingAmount() + " جنيه",
                    invoice.getReceiveDate() != null ? invoice.getReceiveDate().toString() : "غير محدد"
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            System.err.println("خطأ في تحميل الفواتير: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "خطأ في تحميل بيانات الفواتير: " + e.getMessage(), 
                "خطأ", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // Variables declaration
    private javax.swing.JPanel contentPanel;
    private javax.swing.JLabel closeButton;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTable invoicesTable;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration
}

