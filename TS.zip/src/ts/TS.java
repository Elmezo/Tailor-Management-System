
package ts;

public class TS {

  
    public static void main(String[] args) {
       java.awt.EventQueue.invokeLater(new Runnable() {
           public void run() {
               login1 loginFrame = new login1();
               loginFrame.setVisible(true);
           }
       });
    }
    
}
