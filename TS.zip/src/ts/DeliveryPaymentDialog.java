package ts;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.BigDecimal;
import ts.FontManager;
import ts.model.Invoice;
import ts.service.InvoiceService;

/**
 * Dialog for handling invoice delivery with payment options
 */
public class DeliveryPaymentDialog extends javax.swing.JDialog {
    
    private Invoice invoice;
    private boolean deliveryCompleted = false;
    private String selectedPaymentStatus = null;
    private BigDecimal paymentAmount = null;
    
    // UI Components
    private JPanel mainPanel;
    private JPanel headerPanel;
    private JPanel contentPanel;
    private JLabel titleLabel;
    private JLabel closeButton;
    private JLabel invoiceNumberLabel;
    private JLabel customerNameLabel;
    private JLabel totalAmountLabel;
    private JLabel remainingAmountLabel;
    private JLabel paymentStatusLabel;
    private JButton fullPaymentButton;
    private JButton partialPaymentButton;
    private JButton noPaymentButton;
    private JButton confirmButton;
    private JButton cancelButton;
    private JTextField partialAmountField;
    private JLabel partialAmountLabel;
    
    public DeliveryPaymentDialog(java.awt.Frame parent, boolean modal, Invoice invoice) {
        super(parent, modal);
        this.invoice = invoice;
        initComponents();
        setupDialog();
    }
    
    private void initComponents() {
        mainPanel = new JPanel();
        headerPanel = new JPanel();
        titleLabel = new JLabel();
        closeButton = new JLabel();
        contentPanel = new JPanel();
        
        invoiceNumberLabel = new JLabel();
        customerNameLabel = new JLabel();
        totalAmountLabel = new JLabel();
        remainingAmountLabel = new JLabel();
        paymentStatusLabel = new JLabel();
        
        fullPaymentButton = new JButton();
        partialPaymentButton = new JButton();
        noPaymentButton = new JButton();
        confirmButton = new JButton();
        cancelButton = new JButton();
        
        partialAmountField = new JTextField();
        partialAmountLabel = new JLabel();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("تسليم الفاتورة");
        setModal(true);
        setResizable(false);
        
        mainPanel.setBackground(new Color(255, 255, 255));
        mainPanel.setPreferredSize(new Dimension(600, 500));
        mainPanel.setLayout(null);
        
        // Header Panel
        headerPanel.setBackground(new Color(25, 118, 210));
        headerPanel.setPreferredSize(new Dimension(600, 40));
        
        FontManager.applyMontserrat(titleLabel, "ExtraBold", 18f);
        titleLabel.setForeground(new Color(255, 255, 255));
        titleLabel.setText("تسليم الفاتورة");
        titleLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        titleLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        closeButton.setFont(new Font("Arial", Font.BOLD, 18));
        closeButton.setForeground(new Color(255, 255, 255));
        closeButton.setText("✕");
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                dispose();
            }
        });
        
        GroupLayout headerPanelLayout = new GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(closeButton)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 400, Short.MAX_VALUE)
                .addComponent(titleLabel)
                .addGap(20, 20, 20))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(headerPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(closeButton))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        
        mainPanel.add(headerPanel);
        headerPanel.setBounds(0, 0, 600, 40);
        
        // Content Panel
        contentPanel.setBackground(new Color(255, 255, 255));
        contentPanel.setLayout(null);
        
        // Invoice Information
        FontManager.applyMontserrat(invoiceNumberLabel, "Bold", 16f);
        invoiceNumberLabel.setForeground(new Color(25, 118, 210));
        invoiceNumberLabel.setText("رقم الفاتورة: " + invoice.getInvoiceNumber());
        invoiceNumberLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        invoiceNumberLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        FontManager.applyMontserrat(customerNameLabel, "Medium", 15f);
        customerNameLabel.setForeground(new Color(60, 60, 60));
        customerNameLabel.setText("العميل: " + invoice.getCustomerName());
        customerNameLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        customerNameLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        FontManager.applyMontserrat(totalAmountLabel, "Medium", 15f);
        totalAmountLabel.setForeground(new Color(60, 60, 60));
        totalAmountLabel.setText("المبلغ الإجمالي: " + invoice.getTotalAmount() + " جنيه");
        totalAmountLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        totalAmountLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        FontManager.applyMontserrat(remainingAmountLabel, "Bold", 16f);
        remainingAmountLabel.setForeground(new Color(244, 67, 54));
        remainingAmountLabel.setText("المبلغ المتبقي: " + invoice.getRemainingAmount() + " جنيه");
        remainingAmountLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        remainingAmountLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        FontManager.applyMontserrat(paymentStatusLabel, "Bold", 15f);
        paymentStatusLabel.setForeground(new Color(25, 118, 210));
        paymentStatusLabel.setText("حالة الدفع عند التسليم:");
        paymentStatusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        paymentStatusLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        // Payment Buttons
        FontManager.applyMontserrat(fullPaymentButton, "Medium", 14f);
        fullPaymentButton.setBackground(new Color(76, 175, 80));
        fullPaymentButton.setForeground(new Color(255, 255, 255));
        fullPaymentButton.setText("تم دفع المبلغ كامل");
        fullPaymentButton.setBorder(null);
        fullPaymentButton.setFocusPainted(false);
        fullPaymentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        fullPaymentButton.addActionListener(evt -> fullPaymentButtonActionPerformed(evt));
        
        FontManager.applyMontserrat(partialPaymentButton, "Medium", 14f);
        partialPaymentButton.setBackground(new Color(255, 152, 0));
        partialPaymentButton.setForeground(new Color(255, 255, 255));
        partialPaymentButton.setText("تم دفع جزء من المبلغ");
        partialPaymentButton.setBorder(null);
        partialPaymentButton.setFocusPainted(false);
        partialPaymentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        partialPaymentButton.addActionListener(evt -> partialPaymentButtonActionPerformed(evt));
        
        FontManager.applyMontserrat(noPaymentButton, "Medium", 14f);
        noPaymentButton.setBackground(new Color(244, 67, 54));
        noPaymentButton.setForeground(new Color(255, 255, 255));
        noPaymentButton.setText("لم يتم دفع شيء");
        noPaymentButton.setBorder(null);
        noPaymentButton.setFocusPainted(false);
        noPaymentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        noPaymentButton.addActionListener(evt -> noPaymentButtonActionPerformed(evt));
        
        // Partial amount input (initially hidden)
        FontManager.applyMontserrat(partialAmountLabel, "Bold", 14f);
        partialAmountLabel.setForeground(new Color(25, 118, 210));
        partialAmountLabel.setText("المبلغ المدفوع:");
        partialAmountLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        partialAmountLabel.setVisible(false);
        
        FontManager.applyMontserrat(partialAmountField, "Medium", 14f);
        partialAmountField.setBorder(BorderFactory.createLineBorder(new Color(25, 118, 210)));
        partialAmountField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        partialAmountField.setVisible(false);
        
        // Confirm and Cancel buttons
        FontManager.applyMontserrat(confirmButton, "Medium", 16f);
        confirmButton.setBackground(new Color(25, 118, 210));
        confirmButton.setForeground(new Color(255, 255, 255));
        confirmButton.setText("تأكيد التسليم");
        confirmButton.setBorder(null);
        confirmButton.setFocusPainted(false);
        confirmButton.setEnabled(false);
        confirmButton.addActionListener(evt -> confirmButtonActionPerformed(evt));
        
        FontManager.applyMontserrat(cancelButton, "Medium", 16f);
        cancelButton.setBackground(new Color(255, 255, 255));
        cancelButton.setForeground(new Color(25, 118, 210));
        cancelButton.setText("إلغاء");
        cancelButton.setBorder(BorderFactory.createLineBorder(new Color(25, 118, 210)));
        cancelButton.setFocusPainted(false);
        cancelButton.addActionListener(evt -> dispose());
        
        // Add components to content panel
        contentPanel.add(invoiceNumberLabel);
        invoiceNumberLabel.setBounds(50, 20, 500, 25);
        
        contentPanel.add(customerNameLabel);
        customerNameLabel.setBounds(50, 50, 500, 25);
        
        contentPanel.add(totalAmountLabel);
        totalAmountLabel.setBounds(50, 80, 500, 25);
        
        contentPanel.add(remainingAmountLabel);
        remainingAmountLabel.setBounds(50, 110, 500, 25);
        
        contentPanel.add(paymentStatusLabel);
        paymentStatusLabel.setBounds(50, 160, 500, 25);
        
        contentPanel.add(fullPaymentButton);
        fullPaymentButton.setBounds(50, 200, 500, 40);
        
        contentPanel.add(partialPaymentButton);
        partialPaymentButton.setBounds(50, 250, 500, 40);
        
        contentPanel.add(noPaymentButton);
        noPaymentButton.setBounds(50, 300, 500, 40);
        
        contentPanel.add(partialAmountLabel);
        partialAmountLabel.setBounds(50, 350, 500, 25);
        
        contentPanel.add(partialAmountField);
        partialAmountField.setBounds(50, 380, 500, 30);
        
        contentPanel.add(confirmButton);
        confirmButton.setBounds(320, 420, 110, 35);
        
        contentPanel.add(cancelButton);
        cancelButton.setBounds(180, 420, 110, 35);
        
        mainPanel.add(contentPanel);
        contentPanel.setBounds(0, 40, 600, 460);
        
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        
        pack();
    }
    
    private void setupDialog() {
        setLocationRelativeTo(null);
        getContentPane().setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
    }
    
    private void fullPaymentButtonActionPerformed(ActionEvent evt) {
        selectedPaymentStatus = "تم دفع المبلغ كامل";
        paymentAmount = invoice.getRemainingAmount();
        
        // Reset other buttons
        resetButtonStates();
        fullPaymentButton.setBackground(new Color(56, 142, 60));
        
        // Hide partial amount field
        partialAmountLabel.setVisible(false);
        partialAmountField.setVisible(false);
        
        // Enable confirm button
        confirmButton.setEnabled(true);
    }
    
    private void partialPaymentButtonActionPerformed(ActionEvent evt) {
        selectedPaymentStatus = "تم دفع جزء من المبلغ";
        
        // Reset other buttons
        resetButtonStates();
        partialPaymentButton.setBackground(new Color(230, 130, 0));
        
        // Show partial amount field
        partialAmountLabel.setVisible(true);
        partialAmountField.setVisible(true);
        partialAmountField.requestFocus();
        
        // Enable confirm button only if amount is entered
        confirmButton.setEnabled(false);
        
        // Add listener to enable confirm when amount is entered
        partialAmountField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String text = partialAmountField.getText().trim();
                confirmButton.setEnabled(!text.isEmpty());
            }
        });
    }
    
    private void noPaymentButtonActionPerformed(ActionEvent evt) {
        selectedPaymentStatus = "لم يتم دفع شيء";
        paymentAmount = BigDecimal.ZERO;
        
        // Reset other buttons
        resetButtonStates();
        noPaymentButton.setBackground(new Color(211, 47, 47));
        
        // Hide partial amount field
        partialAmountLabel.setVisible(false);
        partialAmountField.setVisible(false);
        
        // Enable confirm button
        confirmButton.setEnabled(true);
    }
    
    private void confirmButtonActionPerformed(ActionEvent evt) {
        try {
            // If partial payment, get the amount
            if ("تم دفع جزء من المبلغ".equals(selectedPaymentStatus)) {
                String amountStr = partialAmountField.getText().trim();
                if (amountStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                        "يرجى إدخال المبلغ المدفوع",
                        "خطأ",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                try {
                    paymentAmount = new BigDecimal(amountStr);
                    if (paymentAmount.compareTo(BigDecimal.ZERO) <= 0) {
                        JOptionPane.showMessageDialog(this,
                            "المبلغ يجب أن يكون أكبر من صفر",
                            "خطأ",
                            JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (paymentAmount.compareTo(invoice.getRemainingAmount()) > 0) {
                        JOptionPane.showMessageDialog(this,
                            "المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ المتبقي",
                            "خطأ",
                            JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this,
                        "يرجى إدخال مبلغ صحيح",
                        "خطأ",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Confirm action
            int confirm = JOptionPane.showConfirmDialog(this,
                "هل أنت متأكد من تسليم الفاتورة؟\n" + selectedPaymentStatus,
                "تأكيد التسليم",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) {
                InvoiceService invoiceService = new InvoiceService();
                boolean success = invoiceService.markAsDelivered(
                    invoice.getInvoiceId(),
                    selectedPaymentStatus,
                    paymentAmount
                );
                
                if (success) {
                    deliveryCompleted = true;
                    JOptionPane.showMessageDialog(this,
                        "تم تسليم الفاتورة بنجاح",
                        "نجح",
                        JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "فشل في تسليم الفاتورة",
                        "خطأ",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this,
                e.getMessage(),
                "خطأ",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "خطأ في تسليم الفاتورة: " + e.getMessage(),
                "خطأ",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void resetButtonStates() {
        fullPaymentButton.setBackground(new Color(76, 175, 80));
        partialPaymentButton.setBackground(new Color(255, 152, 0));
        noPaymentButton.setBackground(new Color(244, 67, 54));
    }
    
    public boolean isDeliveryCompleted() {
        return deliveryCompleted;
    }
}


