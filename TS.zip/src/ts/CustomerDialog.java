package ts;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CustomerDialog extends javax.swing.JDialog {

    public CustomerDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setupDialog();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        closeButton = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        customerLabel = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        phoneLabel = new javax.swing.JLabel();
        phoneField = new javax.swing.JTextField();
        codeLabel = new javax.swing.JLabel();
        codeField = new javax.swing.JTextField();
        deliveryLabel = new javax.swing.JLabel();
        deliveryField = new javax.swing.JTextField();
        receiveLabel = new javax.swing.JLabel();
        receiveField = new javax.swing.JTextField();
        measurementsCheckBox = new javax.swing.JCheckBox();
        pantsTypeLabel = new javax.swing.JLabel();
        pantsTypeCombo = new javax.swing.JComboBox<>();
        pantsLengthLabel = new javax.swing.JLabel();
        pantsLengthField = new javax.swing.JTextField();
        legLabel = new javax.swing.JLabel();
        legCombo = new javax.swing.JComboBox<>();
        detailLabel = new javax.swing.JLabel();
        detailCombo = new javax.swing.JComboBox<>();
        lengthLabel = new javax.swing.JLabel();
        lengthField = new javax.swing.JTextField();
        sleeveLabel = new javax.swing.JLabel();
        sleeveCombo = new javax.swing.JComboBox<>();
        pocketLabel = new javax.swing.JLabel();
        pocketCombo = new javax.swing.JComboBox<>();
        fitLabel = new javax.swing.JLabel();
        fitCombo = new javax.swing.JComboBox<>();
        locationLabel = new javax.swing.JLabel();
        locationCombo = new javax.swing.JComboBox<>();
        legFieldLabel = new javax.swing.JLabel();
        legField = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("إدارة العميل");
        setModal(true);
        setResizable(false);

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setPreferredSize(new java.awt.Dimension(800, 900));
        mainPanel.setLayout(null);

        headerPanel.setBackground(new java.awt.Color(25, 118, 210));
        headerPanel.setPreferredSize(new java.awt.Dimension(800, 40));

        FontManager.applyMontserrat(titleLabel, "ExtraBold", 18f);
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("إضافة عميل جديد");

        closeButton.setFont(new java.awt.Font("Arial", 1, 18));
        closeButton.setForeground(new java.awt.Color(255, 255, 255));
        closeButton.setText("✕");
        closeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        closeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addContainerGap(550, Short.MAX_VALUE)
                .addComponent(titleLabel)
                .addGap(20, 20, 20))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(titleLabel)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        mainPanel.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 40);

        contentPanel.setBackground(new java.awt.Color(255, 255, 255));
        contentPanel.setLayout(null);

        FontManager.applyMontserrat(customerLabel, "Bold", 14f);
        customerLabel.setForeground(new java.awt.Color(25, 118, 210));
        customerLabel.setText("اسم العميل:");

        FontManager.applyMontserrat(nameField, "Medium", 14f);
        nameField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(phoneLabel, "Bold", 14f);
        phoneLabel.setForeground(new java.awt.Color(25, 118, 210));
        phoneLabel.setText("رقم التليفون:");

        FontManager.applyMontserrat(phoneField, "Medium", 14f);
        phoneField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(codeLabel, "Bold", 14f);
        codeLabel.setForeground(new java.awt.Color(25, 118, 210));
        codeLabel.setText("كود العميل:");

        FontManager.applyMontserrat(codeField, "Medium", 14f);
        codeField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(deliveryLabel, "Bold", 14f);
        deliveryLabel.setForeground(new java.awt.Color(25, 118, 210));
        deliveryLabel.setText("تاريخ التسليم:");

        FontManager.applyMontserrat(deliveryField, "Medium", 14f);
        deliveryField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(receiveLabel, "Bold", 14f);
        receiveLabel.setForeground(new java.awt.Color(25, 118, 210));
        receiveLabel.setText("تاريخ الاستلام:");

        FontManager.applyMontserrat(receiveField, "Medium", 14f);
        receiveField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(measurementsCheckBox, "Medium", 13f);
        measurementsCheckBox.setForeground(new java.awt.Color(25, 118, 210));
        measurementsCheckBox.setText("إضافة المقاسات");
        measurementsCheckBox.setBackground(new java.awt.Color(255, 255, 255));
        measurementsCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                measurementsCheckBoxActionPerformed(evt);
            }
        });

        FontManager.applyMontserrat(pantsTypeLabel, "Bold", 14f);
        pantsTypeLabel.setForeground(new java.awt.Color(25, 118, 210));
        pantsTypeLabel.setText("نوع السروال:");

        FontManager.applyMontserrat(pantsTypeCombo, "Medium", 14f);
        pantsTypeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "أستك+دكة", "أستك", "دكة" }));

        FontManager.applyMontserrat(pantsLengthLabel, "Bold", 14f);
        pantsLengthLabel.setForeground(new java.awt.Color(25, 118, 210));
        pantsLengthLabel.setText("طول السروال:");

        FontManager.applyMontserrat(pantsLengthField, "Medium", 14f);
        pantsLengthField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(legLabel, "Bold", 14f);
        legLabel.setForeground(new java.awt.Color(25, 118, 210));
        legLabel.setText("ردة:");

        FontManager.applyMontserrat(legCombo, "Medium", 14f);
        legCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "خليجي", "ردة عالية" }));

        FontManager.applyMontserrat(detailLabel, "Bold", 14f);
        detailLabel.setForeground(new java.awt.Color(25, 118, 210));
        detailLabel.setText("تفصيلة السروال:");

        FontManager.applyMontserrat(detailCombo, "Medium", 14f);
        detailCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "بنطلون", "عادي" }));

        FontManager.applyMontserrat(lengthLabel, "Bold", 14f);
        lengthLabel.setForeground(new java.awt.Color(25, 118, 210));
        lengthLabel.setText("الطول:");

        FontManager.applyMontserrat(lengthField, "Medium", 14f);
        lengthField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(sleeveLabel, "Bold", 14f);
        sleeveLabel.setForeground(new java.awt.Color(25, 118, 210));
        sleeveLabel.setText("الكم:");

        FontManager.applyMontserrat(sleeveCombo, "Medium", 14f);
        sleeveCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "أساور", "مطلوق", "نص كم" }));
        safraLabel = new javax.swing.JLabel();
        safraField = new javax.swing.JTextField();
        bshleikLabel = new javax.swing.JLabel();
        bshleikCombo = new javax.swing.JComboBox<>();
        atkLabel = new javax.swing.JLabel();
        atkCombo = new javax.swing.JComboBox<>();
        
        FontManager.applyMontserrat(safraLabel, "Bold", 14f);
        safraLabel.setForeground(new java.awt.Color(25, 118, 210));
        safraLabel.setText("سفرة:");
        
        FontManager.applyMontserrat(safraField, "Medium", 14f);
        safraField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        FontManager.applyMontserrat(bshleikLabel, "Bold", 14f);
        bshleikLabel.setForeground(new java.awt.Color(25, 118, 210));
        bshleikLabel.setText("بشليك:");
        
        FontManager.applyMontserrat(bshleikCombo, "Medium", 14f);
        bshleikCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "مكشوف", "مكشوف سوستة", "مكشوف كبابيس" }));

        FontManager.applyMontserrat(atkLabel, "Bold", 14f);
        atkLabel.setForeground(new java.awt.Color(25, 118, 210));
        atkLabel.setText("أتك:");
        
        FontManager.applyMontserrat(atkCombo, "Medium", 14f);
        atkCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "كاملة بوز", "قميص بوز" }));
        atkCombo.setEditable(false);

        FontManager.applyMontserrat(pocketLabel, "Bold", 14f);
        pocketLabel.setForeground(new java.awt.Color(25, 118, 210));
        pocketLabel.setText("خزنة:");

        FontManager.applyMontserrat(pocketCombo, "Medium", 14f);
        pocketCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "أصيل", "قطري", "عماني" }));

        FontManager.applyMontserrat(fitLabel, "Bold", 13f);
        fitLabel.setForeground(new java.awt.Color(25, 118, 210));
        fitLabel.setText("لياقة:");

        FontManager.applyMontserrat(fitCombo, "Medium", 14f);
        fitCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "نص", "نص أكاف", "نص دوران" }));
        fitCombo.setEditable(false);

        FontManager.applyMontserrat(locationLabel, "Bold", 14f);
        locationLabel.setForeground(new java.awt.Color(25, 118, 210));
        locationLabel.setText("المكان:");

        FontManager.applyMontserrat(locationCombo, "Medium", 14f);
        locationCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ورشة", "تشطيب", "محل" }));

        FontManager.applyMontserrat(legFieldLabel, "Bold", 14f);
        legFieldLabel.setForeground(new java.awt.Color(25, 118, 210));
        legFieldLabel.setText("رجل:");

        FontManager.applyMontserrat(legField, "Medium", 14f);
        legField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));

        saveButton.setBackground(new java.awt.Color(25, 118, 210));
        FontManager.applyMontserrat(saveButton, "Medium", 16f);
        saveButton.setForeground(new java.awt.Color(255, 255, 255));
        saveButton.setText("حفظ");
        saveButton.setBorder(null);
        saveButton.setFocusPainted(false);
        saveButton.setPreferredSize(new java.awt.Dimension(120, 40));
        saveButton.setMinimumSize(new java.awt.Dimension(100, 35));
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        cancelButton.setBackground(new java.awt.Color(255, 255, 255));
        FontManager.applyMontserrat(cancelButton, "Medium", 16f);
        cancelButton.setForeground(new java.awt.Color(25, 118, 210));
        cancelButton.setText("إلغاء");
        cancelButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(25, 118, 210)));
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new java.awt.Dimension(120, 40));
        cancelButton.setMinimumSize(new java.awt.Dimension(100, 35));
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        contentPanel.add(customerLabel);
        customerLabel.setBounds(620, 10, 150, 18);
        contentPanel.add(nameField);
        nameField.setBounds(80, 10, 500, 24);
        contentPanel.add(phoneLabel);
        phoneLabel.setBounds(620, 40, 150, 18);
        contentPanel.add(phoneField);
        phoneField.setBounds(80, 40, 500, 24);
        
        contentPanel.add(codeLabel);
        codeLabel.setBounds(620, 70, 150, 18);
        contentPanel.add(codeField);
        codeField.setBounds(80, 70, 500, 24);
        
        // Hide date fields for customer (they're only for invoices)
        deliveryLabel.setVisible(false);
        deliveryField.setVisible(false);
        receiveLabel.setVisible(false);
        receiveField.setVisible(false);
        
        contentPanel.add(measurementsCheckBox);
        measurementsCheckBox.setBounds(180, 100, 150, 20);
        
        contentPanel.add(pantsTypeLabel);
        pantsTypeLabel.setBounds(620, 130, 150, 18);
        contentPanel.add(pantsTypeCombo);
        pantsTypeCombo.setBounds(80, 130, 480, 22);
        
        contentPanel.add(pantsLengthLabel);
        pantsLengthLabel.setBounds(620, 160, 150, 18);
        contentPanel.add(pantsLengthField);
        pantsLengthField.setBounds(80, 160, 480, 22);
        
        contentPanel.add(legFieldLabel);
        legFieldLabel.setBounds(620, 190, 150, 18);
        contentPanel.add(legField);
        legField.setBounds(80, 190, 480, 22);
        
        contentPanel.add(legLabel);
        legLabel.setBounds(620, 220, 150, 18);
        contentPanel.add(legCombo);
        legCombo.setBounds(80, 220, 480, 22);
        
        contentPanel.add(detailLabel);
        detailLabel.setBounds(620, 250, 150, 18);
        contentPanel.add(detailCombo);
        detailCombo.setBounds(80, 250, 480, 22);
        
        contentPanel.add(lengthLabel);
        lengthLabel.setBounds(620, 280, 150, 18);
        contentPanel.add(lengthField);
        lengthField.setBounds(80, 280, 480, 22);
        
        contentPanel.add(sleeveLabel);
        sleeveLabel.setBounds(620, 310, 150, 18);
        contentPanel.add(sleeveCombo);
        sleeveCombo.setBounds(80, 310, 480, 22);
        
        contentPanel.add(safraLabel);
        safraLabel.setBounds(620, 340, 150, 18);
        contentPanel.add(safraField);
        safraField.setBounds(80, 340, 480, 22);
        
        contentPanel.add(pocketLabel);
        pocketLabel.setBounds(620, 370, 150, 18);
        contentPanel.add(pocketCombo);
        pocketCombo.setBounds(80, 370, 480, 22);
        
        contentPanel.add(bshleikLabel);
        bshleikLabel.setBounds(620, 400, 150, 18);
        contentPanel.add(bshleikCombo);
        bshleikCombo.setBounds(80, 400, 480, 22);

        contentPanel.add(fitLabel);
        fitLabel.setBounds(620, 430, 150, 18);
        contentPanel.add(fitCombo);
        fitCombo.setBounds(80, 430, 480, 22);

        contentPanel.add(atkLabel);
        atkLabel.setBounds(620, 460, 150, 18);
        contentPanel.add(atkCombo);
        atkCombo.setBounds(80, 460, 480, 22);

        contentPanel.add(locationLabel);
        locationLabel.setBounds(620, 490, 150, 18);
        contentPanel.add(locationCombo);
        locationCombo.setBounds(80, 490, 480, 22);
        
        contentPanel.add(saveButton);
        int buttonsYInit = 100 + (int)Math.round(17 * 28.35);
        saveButton.setBounds(360, buttonsYInit, 110, 32);
        contentPanel.add(cancelButton);
        cancelButton.setBounds(220, buttonsYInit, 110, 32);

        mainPanel.add(contentPanel);
        contentPanel.setBounds(0, 40, 800, 850);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 900, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }

    private void closeButtonMouseClicked(java.awt.event.MouseEvent evt) {
        dispose();
    }

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {
        if (validateFields()) {
            try {
                ts.service.CustomerService customerService = new ts.service.CustomerService();
                
                // Create customer without dates (dates are only for invoices)
                ts.model.Customer customer = new ts.model.Customer(
                    codeField.getText().trim(),
                    nameField.getText().trim(),
                    phoneField.getText().trim(),
                    null,
                    null
                );
                
                // Create measurement if checkbox is selected
                ts.model.Measurement measurement = null;
                if (measurementsCheckBox.isSelected()) {
                    measurement = new ts.model.Measurement();
                    measurement.setPantsType((String) pantsTypeCombo.getSelectedItem());
                    measurement.setPantsLength(pantsLengthField.getText().trim());
                    measurement.setLeg(legField.getText().trim());
                    measurement.setLegType((String) legCombo.getSelectedItem());
                    measurement.setDetail((String) detailCombo.getSelectedItem());
                    measurement.setLength(lengthField.getText().trim());
                    measurement.setSleeve((String) sleeveCombo.getSelectedItem());
                    measurement.setSafra(safraField.getText().trim());
                    measurement.setPocket((String) pocketCombo.getSelectedItem());
                    measurement.setBshleik((String) bshleikCombo.getSelectedItem());
                    measurement.setFit((String) fitCombo.getSelectedItem());
                    measurement.setAtk((String) atkCombo.getSelectedItem());
                    measurement.setLocation((String) locationCombo.getSelectedItem());
                }
                
                boolean success = customerService.createCustomer(customer, measurement);
                
                if (success) {
                    JOptionPane.showMessageDialog(this, "تم حفظ بيانات العميل بنجاح", "نجح", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "فشل في حفظ بيانات العميل", "خطأ", JOptionPane.ERROR_MESSAGE);
                }
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "خطأ", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "خطأ في الاتصال بقاعدة البيانات: " + e.getMessage(), "خطأ", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();
    }

    private void measurementsCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {
        boolean showMeasurements = measurementsCheckBox.isSelected();
        
        pantsTypeLabel.setVisible(showMeasurements);
        pantsTypeCombo.setVisible(showMeasurements);
        pantsLengthLabel.setVisible(showMeasurements);
        pantsLengthField.setVisible(showMeasurements);
        legFieldLabel.setVisible(showMeasurements);
        legField.setVisible(showMeasurements);
        legLabel.setVisible(showMeasurements);
        legCombo.setVisible(showMeasurements);
        detailLabel.setVisible(showMeasurements);
        detailCombo.setVisible(showMeasurements);
        lengthLabel.setVisible(showMeasurements);
        lengthField.setVisible(showMeasurements);
        sleeveLabel.setVisible(showMeasurements);
        sleeveCombo.setVisible(showMeasurements);
        safraLabel.setVisible(showMeasurements);
        safraField.setVisible(showMeasurements);
        bshleikLabel.setVisible(showMeasurements);
        bshleikCombo.setVisible(showMeasurements);
        pocketLabel.setVisible(showMeasurements);
        pocketCombo.setVisible(showMeasurements);
        fitLabel.setVisible(showMeasurements);
        fitCombo.setVisible(showMeasurements);
        atkLabel.setVisible(showMeasurements);
        atkCombo.setVisible(showMeasurements);
        locationLabel.setVisible(showMeasurements);
        locationCombo.setVisible(showMeasurements);
        
        int buttonsY = 165 + (int)Math.round(17 * 28.35);
        saveButton.setBounds(360, buttonsY, 110, 32);
        cancelButton.setBounds(220, buttonsY, 110, 32);
        
        saveButton.setVisible(true);
        cancelButton.setVisible(true);
        
        mainPanel.setPreferredSize(new java.awt.Dimension(800, 850));
        contentPanel.setBounds(0, 40, 800, 810);
        
        pack();
    }

    private void setupDialog() {
        setLocationRelativeTo(null);
        getContentPane().setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        // Auto-generate customer code
        try {
            ts.service.CustomerService customerService = new ts.service.CustomerService();
            String nextCode = customerService.generateNextCustomerCode();
            codeField.setText(nextCode);
        } catch (Exception e) {
            System.err.println("خطأ في توليد كود العميل: " + e.getMessage());
        }
        
        nameField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        phoneField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        codeField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pantsLengthField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        legField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        lengthField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        safraField.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        customerLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        phoneLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        codeLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pantsTypeLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pantsLengthLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        legFieldLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        legLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        detailLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        lengthLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        sleeveLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pocketLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        fitLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        locationLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        titleLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        safraLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        bshleikLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        atkLabel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        
        pantsTypeCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pantsTypeCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });

        fitCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Object selected = fitCombo.getSelectedItem();
                if (selected == null) return;
                String value = selected.toString();
                if ("نص".equals(value)) {
                    String input = JOptionPane.showInputDialog(CustomerDialog.this, "أدخل رقم السنتيمتر للياقة النص:", "إدخال رقم", JOptionPane.QUESTION_MESSAGE);
                    if (input != null && !input.trim().isEmpty()) {
                        String formatted = "نص (" + input.trim() + ") سم";
                        ensureOptionSelected(fitCombo, formatted);
                    }
                }
            }
        });

        atkCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Object selected = atkCombo.getSelectedItem();
                if (selected == null) return;
                String value = selected.toString();
                if ("كاملة بوز".equals(value)) {
                    String input = JOptionPane.showInputDialog(CustomerDialog.this, "أدخل رقم السنتيمتر:", "إدخال رقم", JOptionPane.QUESTION_MESSAGE);
                    if (input != null && !input.trim().isEmpty()) {
                        String formatted = "كاملة بوز (" + input.trim() + ") سم";
                        ensureOptionSelected(atkCombo, formatted);
                    }
                }
            }
        });

        
        legCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        legCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        detailCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        detailCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        sleeveCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        sleeveCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        pocketCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        pocketCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        fitCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        fitCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        locationCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        locationCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });
        
        bshleikCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        bshleikCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 14f));
                return c;
            }
        });

        atkCombo.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        atkCombo.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
                setHorizontalAlignment(SwingConstants.RIGHT);
                c.setFont(FontManager.getMontserrat("Medium", 13f));
                return c;
            }
        });
        
        measurementsCheckBox.setSelected(true);
        pantsTypeLabel.setVisible(true);
        pantsTypeCombo.setVisible(true);
        pantsLengthLabel.setVisible(true);
        pantsLengthField.setVisible(true);
        legFieldLabel.setVisible(true);
        legField.setVisible(true);
        legLabel.setVisible(true);
        legCombo.setVisible(true);
        detailLabel.setVisible(true);
        detailCombo.setVisible(true);
        lengthLabel.setVisible(true);
        lengthField.setVisible(true);
        sleeveLabel.setVisible(true);
        sleeveCombo.setVisible(true);
        pocketLabel.setVisible(true);
        pocketCombo.setVisible(true);
        fitLabel.setVisible(true);
        fitCombo.setVisible(true);
        locationLabel.setVisible(true);
        locationCombo.setVisible(true);
        bshleikLabel.setVisible(true);
        bshleikCombo.setVisible(true);
        atkLabel.setVisible(true);
        atkCombo.setVisible(true);
        safraLabel.setVisible(true);
        safraField.setVisible(true);
        
        saveButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                saveButton.setBackground(new Color(0, 133, 184));
            }
            
            public void mouseExited(MouseEvent e) {
                saveButton.setBackground(new Color(0, 153, 204));
            }
        });
        
        cancelButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                cancelButton.setBackground(new Color(240, 240, 240));
            }
            
            public void mouseExited(MouseEvent e) {
                cancelButton.setBackground(Color.WHITE);
            }
        });
    }
    
    private boolean validateFields() {
        if (nameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "يرجى إدخال اسم العميل", "خطأ", JOptionPane.ERROR_MESSAGE);
            nameField.requestFocus();
            return false;
        }
        
        if (phoneField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "يرجى إدخال رقم التليفون", "خطأ", JOptionPane.ERROR_MESSAGE);
            phoneField.requestFocus();
            return false;
        }
        
        if (codeField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "يرجى إدخال كود العميل", "خطأ", JOptionPane.ERROR_MESSAGE);
            codeField.requestFocus();
            return false;
        }
        
        return true;
    }

    private void ensureOptionSelected(javax.swing.JComboBox<String> combo, String value) {
        javax.swing.ComboBoxModel<String> model = combo.getModel();
        boolean exists = false;
        for (int i = 0; i < model.getSize(); i++) {
            if (value.equals(model.getElementAt(i))) {
                exists = true;
                break;
            }
        }
        if (!exists && model instanceof javax.swing.DefaultComboBoxModel) {
            ((javax.swing.DefaultComboBoxModel<String>) model).addElement(value);
        }
        combo.setSelectedItem(value);
    }

    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel closeButton;
    private javax.swing.JPanel contentPanel;
    private javax.swing.JTextField nameField;
    private javax.swing.JLabel customerLabel;
    private javax.swing.JTextField phoneField;
    private javax.swing.JLabel phoneLabel;
    private javax.swing.JButton saveButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JTextField codeField;
    private javax.swing.JLabel codeLabel;
    private javax.swing.JTextField deliveryField;
    private javax.swing.JLabel deliveryLabel;
    private javax.swing.JTextField receiveField;
    private javax.swing.JLabel receiveLabel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JCheckBox measurementsCheckBox;
    private javax.swing.JLabel pantsTypeLabel;
    private javax.swing.JComboBox<String> pantsTypeCombo;
    private javax.swing.JLabel pantsLengthLabel;
    private javax.swing.JTextField pantsLengthField;
    private javax.swing.JLabel legLabel;
    private javax.swing.JComboBox<String> legCombo;
    private javax.swing.JLabel detailLabel;
    private javax.swing.JComboBox<String> detailCombo;
    private javax.swing.JLabel sleeveLabel;
    private javax.swing.JComboBox<String> sleeveCombo;
    private javax.swing.JLabel lengthLabel;
    private javax.swing.JTextField lengthField;
    private javax.swing.JLabel pocketLabel;
    private javax.swing.JComboBox<String> pocketCombo;
    private javax.swing.JLabel fitLabel;
    private javax.swing.JComboBox<String> fitCombo;
    private javax.swing.JLabel locationLabel;
    private javax.swing.JComboBox<String> locationCombo;
    private javax.swing.JLabel legFieldLabel;
    private javax.swing.JTextField legField;
    private javax.swing.JLabel safraLabel;
    private javax.swing.JTextField safraField;
    private javax.swing.JLabel bshleikLabel;
    private javax.swing.JComboBox<String> bshleikCombo;
    private javax.swing.JLabel atkLabel;
    private javax.swing.JComboBox<String> atkCombo;
} 