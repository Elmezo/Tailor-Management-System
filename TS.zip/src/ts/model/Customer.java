package ts.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Customer {
    private int customerId;
    private String customerCode;
    private String name;
    private String phone;
    private Date deliveryDate;
    private Date receiveDate;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    public Customer() {}
    
    public Customer(String customerCode, String name, String phone, Date deliveryDate, Date receiveDate) {
        this.customerCode = customerCode;
        this.name = name;
        this.phone = phone;
        this.deliveryDate = deliveryDate;
        this.receiveDate = receiveDate;
    }
    
    // Getters and Setters
    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public String getCustomerCode() {
        return customerCode;
    }
    
    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public Date getDeliveryDate() {
        return deliveryDate;
    }
    
    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }
    
    public Date getReceiveDate() {
        return receiveDate;
    }
    
    public void setReceiveDate(Date receiveDate) {
        this.receiveDate = receiveDate;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}

