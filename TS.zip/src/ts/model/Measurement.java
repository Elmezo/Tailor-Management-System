package ts.model;

import java.sql.Timestamp;

public class Measurement {
    private int measurementId;
    private int customerId;
    private String pantsType;
    private String pantsLength;
    private String leg;
    private String legType;
    private String detail;
    private String length;
    private String sleeve;
    private String safra;
    private String pocket;
    private String bshleik;
    private String fit;
    private String atk;
    private String location;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    public Measurement() {}
    
    // Getters and Setters
    public int getMeasurementId() {
        return measurementId;
    }
    
    public void setMeasurementId(int measurementId) {
        this.measurementId = measurementId;
    }
    
    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public String getPantsType() {
        return pantsType;
    }
    
    public void setPantsType(String pantsType) {
        this.pantsType = pantsType;
    }
    
    public String getPantsLength() {
        return pantsLength;
    }
    
    public void setPantsLength(String pantsLength) {
        this.pantsLength = pantsLength;
    }
    
    public String getLeg() {
        return leg;
    }
    
    public void setLeg(String leg) {
        this.leg = leg;
    }
    
    public String getLegType() {
        return legType;
    }
    
    public void setLegType(String legType) {
        this.legType = legType;
    }
    
    public String getDetail() {
        return detail;
    }
    
    public void setDetail(String detail) {
        this.detail = detail;
    }
    
    public String getLength() {
        return length;
    }
    
    public void setLength(String length) {
        this.length = length;
    }
    
    public String getSleeve() {
        return sleeve;
    }
    
    public void setSleeve(String sleeve) {
        this.sleeve = sleeve;
    }
    
    public String getSafra() {
        return safra;
    }
    
    public void setSafra(String safra) {
        this.safra = safra;
    }
    
    public String getPocket() {
        return pocket;
    }
    
    public void setPocket(String pocket) {
        this.pocket = pocket;
    }
    
    public String getBshleik() {
        return bshleik;
    }
    
    public void setBshleik(String bshleik) {
        this.bshleik = bshleik;
    }
    
    public String getFit() {
        return fit;
    }
    
    public void setFit(String fit) {
        this.fit = fit;
    }
    
    public String getAtk() {
        return atk;
    }
    
    public void setAtk(String atk) {
        this.atk = atk;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
}

