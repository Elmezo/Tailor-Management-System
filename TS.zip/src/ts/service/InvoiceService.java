package ts.service;

import ts.dao.InvoiceDAO;
import ts.dao.CustomerDAO;
import ts.model.Invoice;
import ts.model.Measurement;
import ts.util.DateFormatter;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

public class InvoiceService {
    private InvoiceDAO invoiceDAO;
    private CustomerDAO customerDAO;
    
    public InvoiceService() {
        this.invoiceDAO = new InvoiceDAO();
        this.customerDAO = new CustomerDAO();
    }
    
    public boolean createInvoice(Invoice invoice, Measurement measurement) {
        // Validation
        if (invoice.getCustomerId() <= 0) {
            throw new IllegalArgumentException("يرجى اختيار العميل");
        }
        if (invoice.getTotalAmount() == null || invoice.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("يرجى إدخال المبلغ الإجمالي");
        }
        
        // Set delivery date to today if not provided
        if (invoice.getDeliveryDate() == null) {
            invoice.setDeliveryDate(DateFormatter.getCurrentDate());
        }
        
        if (invoice.getReceiveDate() == null) {
            throw new IllegalArgumentException("يرجى إدخال تاريخ الاستلام");
        }
        
        // Validate paid amount
        if (invoice.getPaidAmount() == null) {
            invoice.setPaidAmount(BigDecimal.ZERO);
        }
        
        // Check if paid amount exceeds total amount
        if (invoice.getPaidAmount().compareTo(invoice.getTotalAmount()) > 0) {
            throw new IllegalArgumentException("المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ الإجمالي");
        }
        
        // Generate invoice number if not provided
        if (invoice.getInvoiceNumber() == null || invoice.getInvoiceNumber().trim().isEmpty()) {
            invoice.setInvoiceNumber(generateNextInvoiceNumber());
        }
        
        // Calculate remaining amount (with protection against negative values)
        BigDecimal remaining = invoice.getTotalAmount().subtract(invoice.getPaidAmount());
        invoice.setRemainingAmount(remaining.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : remaining);
        
        // Always set status to "غير مكتمل" when creating a new invoice
        // Status should only be changed to "مكتمل" manually via the complete invoice button
        invoice.setStatus("غير مكتمل");
        
        // Create invoice
        boolean invoiceCreated = invoiceDAO.createInvoice(invoice);
        
        // Create invoice measurement if provided and invoice was created successfully
        if (invoiceCreated && measurement != null) {
            invoiceDAO.createInvoiceMeasurement(invoice.getInvoiceId(), measurement);
        }
        
        // Record initial payment if any (only if there's an initial payment)
        // Note: We create the payment record, but the paid_amount in invoice is already set
        // The trigger will add it again, so we need to adjust: set paid_amount to 0 first, then let trigger add it
        // Actually, better approach: don't create payment record for initial amount, just store it in invoice
        // Only create payment records for subsequent payments made after invoice creation
        // So we'll comment this out to prevent double-counting
        /*
        if (invoiceCreated && invoice.getPaidAmount().compareTo(BigDecimal.ZERO) > 0) {
            ts.dao.PaymentDAO paymentDAO = new ts.dao.PaymentDAO();
            ts.model.Payment initialPayment = new ts.model.Payment(
                invoice.getInvoiceId(), 
                invoice.getPaidAmount(), 
                "دفعة أولية عند إنشاء الفاتورة"
            );
            paymentDAO.createPayment(initialPayment);
        }
        */
        
        return invoiceCreated;
    }
    
    public Invoice getInvoiceById(int invoiceId) {
        return invoiceDAO.getInvoiceById(invoiceId);
    }
    
    public Invoice getInvoiceByNumber(String invoiceNumber) {
        return invoiceDAO.getInvoiceByNumber(invoiceNumber);
    }
    
    public List<Invoice> getAllInvoices() {
        return invoiceDAO.getAllInvoices();
    }
    
    public List<Invoice> getInvoicesByCustomerId(int customerId) {
        return invoiceDAO.getInvoicesByCustomerId(customerId);
    }
    
    public List<Invoice> searchInvoices(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllInvoices();
        }
        return invoiceDAO.searchInvoices(searchTerm.trim());
    }
    
    public boolean updateInvoice(Invoice invoice) {
        return invoiceDAO.updateInvoice(invoice);
    }
    
    public boolean deleteInvoice(int invoiceId) {
        return invoiceDAO.deleteInvoice(invoiceId);
    }
    
    public String generateNextInvoiceNumber() {
        return invoiceDAO.generateNextInvoiceNumber();
    }
    
    public Date parseDate(String dateStr) {
        return DateFormatter.parseDate(dateStr);
    }
    
    public BigDecimal parseBigDecimal(String amountStr) {
        if (amountStr == null || amountStr.trim().isEmpty()) {
            return BigDecimal.ZERO;
        }
        try {
            return new BigDecimal(amountStr.trim());
        } catch (NumberFormatException e) {
            System.err.println("خطأ في تحويل المبلغ: " + e.getMessage());
            return BigDecimal.ZERO;
        }
    }
    
    public boolean markAsDelivered(int invoiceId, String paymentStatus, BigDecimal paymentAmount) {
        try {
            // Get the invoice
            Invoice invoice = invoiceDAO.getInvoiceById(invoiceId);
            if (invoice == null) {
                throw new IllegalArgumentException("الفاتورة غير موجودة");
            }
            
            // Check if already delivered
            if ("تم التسليم".equals(invoice.getDeliveryStatus())) {
                throw new IllegalArgumentException("تم تسليم الفاتورة مسبقاً");
            }
            
            // Update delivery status
            invoice.setDeliveryStatus("تم التسليم");
            invoice.setDeliveryPaymentStatus(paymentStatus);
            
            // If there's a payment, create payment record
            if (paymentAmount != null && paymentAmount.compareTo(BigDecimal.ZERO) > 0) {
                // Validate payment amount doesn't exceed remaining
                if (paymentAmount.compareTo(invoice.getRemainingAmount()) > 0) {
                    throw new IllegalArgumentException("المبلغ المدفوع لا يمكن أن يكون أكبر من المبلغ المتبقي");
                }
                
                // Create payment record
                ts.dao.PaymentDAO paymentDAO = new ts.dao.PaymentDAO();
                ts.model.Payment payment = new ts.model.Payment(
                    invoiceId,
                    paymentAmount,
                    "دفعة عند التسليم - " + paymentStatus
                );
                boolean paymentCreated = paymentDAO.createPayment(payment);
                
                if (!paymentCreated) {
                    throw new RuntimeException("فشل في تسجيل الدفعة");
                }
                
                // Update invoice amounts
                BigDecimal newPaidAmount = invoice.getPaidAmount().add(paymentAmount);
                BigDecimal newRemainingAmount = invoice.getTotalAmount().subtract(newPaidAmount);
                invoice.setPaidAmount(newPaidAmount);
                invoice.setRemainingAmount(newRemainingAmount.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : newRemainingAmount);
            }
            
            // Update the invoice
            return invoiceDAO.updateInvoice(invoice);
            
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            System.err.println("خطأ في تسليم الفاتورة: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}

