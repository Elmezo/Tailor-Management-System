package ts.service;

import ts.dao.UserDAO;
import ts.model.User;

public class AuthService {
    private UserDAO userDAO;
    
    public AuthService() {
        this.userDAO = new UserDAO();
    }
    
    public User login(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }
        if (password == null || password.trim().isEmpty()) {
            return null;
        }
        
        User user = userDAO.getUserByUsername(username.trim());
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
    
    public boolean register(String username, String password, String fullName, String phone) {
        // Validation
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال اسم المستخدم");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال كلمة المرور");
        }
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال الاسم الكامل");
        }
        if (phone == null || phone.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال رقم التليفون");
        }
        
        // Check if username already exists
        if (userDAO.usernameExists(username.trim())) {
            throw new IllegalArgumentException("اسم المستخدم موجود بالفعل");
        }
        
        User user = new User(username.trim(), password, fullName.trim(), phone.trim());
        return userDAO.createUser(user);
    }
    
    public boolean resetPassword(String username, String phone, String newPassword) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال اسم المستخدم");
        }
        if (phone == null || phone.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال رقم التليفون");
        }
        if (newPassword == null || newPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال كلمة المرور الجديدة");
        }
        
        User user = userDAO.getUserByUsernameAndPhone(username.trim(), phone.trim());
        if (user == null) {
            throw new IllegalArgumentException("اسم المستخدم أو رقم التليفون غير صحيح");
        }
        
        return userDAO.updatePassword(username.trim(), newPassword);
    }
    
    public User getUserByUsernameAndPhone(String username, String phone) {
        return userDAO.getUserByUsernameAndPhone(username, phone);
    }
}

