package ts.service;

import ts.dao.PaymentDAO;
import ts.dao.InvoiceDAO;
import ts.model.Payment;
import ts.model.Invoice;
import java.math.BigDecimal;
import java.util.List;

public class PaymentService {
    private PaymentDAO paymentDAO;
    private InvoiceDAO invoiceDAO;
    
    public PaymentService() {
        this.paymentDAO = new PaymentDAO();
        this.invoiceDAO = new InvoiceDAO();
    }
    
    public boolean createPayment(int invoiceId, BigDecimal amount, String notes) {
        // Validation
        if (invoiceId <= 0) {
            throw new IllegalArgumentException("يرجى اختيار الفاتورة");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("يرجى إدخال مبلغ صحيح");
        }
        
        // Get invoice
        Invoice invoice = invoiceDAO.getInvoiceById(invoiceId);
        if (invoice == null) {
            throw new IllegalArgumentException("الفاتورة غير موجودة");
        }
        
        // Check if amount exceeds remaining
        if (amount.compareTo(invoice.getRemainingAmount()) > 0) {
            throw new IllegalArgumentException("المبلغ المدفوع أكبر من المبلغ المتبقي");
        }
        
        // Create payment
        Payment payment = new Payment(invoiceId, amount, notes);
        boolean paymentCreated = paymentDAO.createPayment(payment);
        
        // Note: The trigger in database will automatically update invoice amounts
        // But we can also do it here for immediate feedback
        if (paymentCreated) {
            invoice.setPaidAmount(invoice.getPaidAmount().add(amount));
            // Don't manually set remaining_amount, let setPaidAmount() calculate it automatically
            // via calculateRemaining() method in Invoice model
            
            // Update status if fully paid
            if (invoice.getRemainingAmount().compareTo(BigDecimal.ZERO) <= 0) {
                invoice.setStatus("مكتمل");
            }
            
            invoiceDAO.updateInvoice(invoice);
        }
        
        return paymentCreated;
    }
    
    public Payment getPaymentById(int paymentId) {
        return paymentDAO.getPaymentById(paymentId);
    }
    
    public List<Payment> getPaymentsByInvoiceId(int invoiceId) {
        return paymentDAO.getPaymentsByInvoiceId(invoiceId);
    }
    
    public List<Payment> getAllPayments() {
        return paymentDAO.getAllPayments();
    }
    
    public boolean deletePayment(int paymentId) {
        // Note: The trigger in database will automatically update invoice amounts
        return paymentDAO.deletePayment(paymentId);
    }
    
    public BigDecimal parseBigDecimal(String amountStr) {
        if (amountStr == null || amountStr.trim().isEmpty()) {
            return BigDecimal.ZERO;
        }
        try {
            // Remove any non-numeric characters except decimal point
            String cleaned = amountStr.trim().replaceAll("[^0-9.]", "");
            return new BigDecimal(cleaned);
        } catch (NumberFormatException e) {
            System.err.println("خطأ في تحويل المبلغ: " + e.getMessage());
            return BigDecimal.ZERO;
        }
    }
}

