package ts.service;

import ts.dao.CustomerDAO;
import ts.dao.InvoiceDAO;
import ts.dao.PaymentDAO;
import ts.model.Customer;
import ts.model.Invoice;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Comparator;
import java.util.stream.Collectors;

public class ReportService {
    private CustomerDAO customerDAO;
    private InvoiceDAO invoiceDAO;
    private PaymentDAO paymentDAO;
    
    public ReportService() {
        this.customerDAO = new CustomerDAO();
        this.invoiceDAO = new InvoiceDAO();
        this.paymentDAO = new PaymentDAO();
    }
    
    public List<Map<String, Object>> getCustomersWithRemaining() {
        List<Customer> customers = customerDAO.getAllCustomers();
        List<Invoice> allInvoices = invoiceDAO.getAllInvoices();
        
        return customers.stream().map(customer -> {
            Map<String, Object> row = new HashMap<>();
            row.put("customer_id", customer.getCustomerId());
            row.put("name", customer.getName());
            row.put("phone", customer.getPhone());
            row.put("customer_code", customer.getCustomerCode());
            
            // Calculate total remaining for this customer
            BigDecimal totalRemaining = allInvoices.stream()
                .filter(inv -> inv.getCustomerId() == customer.getCustomerId())
                .map(Invoice::getRemainingAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Count orders
            long orderCount = allInvoices.stream()
                .filter(inv -> inv.getCustomerId() == customer.getCustomerId())
                .count();
            
            row.put("total_remaining", totalRemaining);
            row.put("order_count", orderCount);
            row.put("delivery_date", customer.getDeliveryDate());
            
            return row;
        }).filter(row -> ((BigDecimal) row.get("total_remaining")).compareTo(BigDecimal.ZERO) > 0)
          .sorted((r1, r2) -> ((BigDecimal) r2.get("total_remaining")).compareTo((BigDecimal) r1.get("total_remaining")))
          .collect(Collectors.toList());
    }
    
    public List<Map<String, Object>> getAllCustomersSummary() {
        List<Customer> customers = customerDAO.getAllCustomers();
        List<Invoice> allInvoices = invoiceDAO.getAllInvoices();
        
        return customers.stream().map(customer -> {
            Map<String, Object> row = new HashMap<>();
            row.put("customer_id", customer.getCustomerId());
            row.put("name", customer.getName());
            row.put("phone", customer.getPhone());
            row.put("customer_code", customer.getCustomerCode());
            
            // Calculate total remaining for this customer
            BigDecimal totalRemaining = allInvoices.stream()
                .filter(inv -> inv.getCustomerId() == customer.getCustomerId())
                .map(Invoice::getRemainingAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Count orders
            long orderCount = allInvoices.stream()
                .filter(inv -> inv.getCustomerId() == customer.getCustomerId())
                .count();
            
            row.put("total_remaining", totalRemaining);
            row.put("order_count", orderCount);
            row.put("delivery_date", customer.getDeliveryDate());
            
            return row;
        }).sorted((r1, r2) -> ((BigDecimal) r2.get("total_remaining")).compareTo((BigDecimal) r1.get("total_remaining")))
          .collect(Collectors.toList());
    }
    
    public List<Invoice> getDetailedInvoiceReport() {
        return invoiceDAO.getAllInvoices();
    }
    
    public Map<String, Object> getDashboardStatistics() {
        Map<String, Object> stats = new HashMap<>();
        
        List<Customer> customers = customerDAO.getAllCustomers();
        List<Invoice> invoices = invoiceDAO.getAllInvoices();
        
        // Total customers
        stats.put("total_customers", customers.size());
        
        // Active invoices (not completed) - using "غير مكتمل" status
        long activeInvoices = invoices.stream()
            .filter(inv -> "غير مكتمل".equals(inv.getStatus()))
            .count();
        stats.put("active_invoices", activeInvoices);
        
        // Total remaining to collect
        BigDecimal totalRemaining = invoices.stream()
            .map(Invoice::getRemainingAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.put("total_remaining", totalRemaining);
        
        // Today's revenue (all payments made today)
        java.sql.Date today = new java.sql.Date(System.currentTimeMillis());
        List<ts.model.Payment> todayPayments = paymentDAO.getPaymentsByDate(today);
        BigDecimal todayRevenue = todayPayments.stream()
            .map(ts.model.Payment::getAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.put("today_revenue", todayRevenue);
        
        return stats;
    }
    
    /**
     * Get upcoming invoices sorted by receive date (closest first)
     * Only includes incomplete invoices
     */
    public List<Invoice> getUpcomingInvoices() {
        List<Invoice> invoices = invoiceDAO.getAllInvoices();
        Date today = new Date(System.currentTimeMillis());
        
        return invoices.stream()
            .filter(inv -> "غير مكتمل".equals(inv.getStatus()))
            .filter(inv -> inv.getReceiveDate() != null)
            .sorted(Comparator.comparing(Invoice::getReceiveDate))
            .collect(Collectors.toList());
    }
    
    /**
     * Get count of active (incomplete) invoices
     */
    public long getActiveInvoicesCount() {
        List<Invoice> invoices = invoiceDAO.getAllInvoices();
        return invoices.stream()
            .filter(inv -> "غير مكتمل".equals(inv.getStatus()))
            .count();
    }
    
    public List<Map<String, Object>> searchCustomerReport(String searchTerm) {
        List<Map<String, Object>> allData = getAllCustomersSummary();
        
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return allData;
        }
        
        String search = searchTerm.trim().toLowerCase();
        return allData.stream()
            .filter(row -> {
                String name = ((String) row.get("name")).toLowerCase();
                String phone = ((String) row.get("phone")).toLowerCase();
                String code = ((String) row.get("customer_code")).toLowerCase();
                return name.contains(search) || phone.contains(search) || code.contains(search);
            })
            .collect(Collectors.toList());
    }
    
    public List<Invoice> searchInvoiceReport(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getDetailedInvoiceReport();
        }
        return invoiceDAO.searchInvoices(searchTerm.trim());
    }
}

