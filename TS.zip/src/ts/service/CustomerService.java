package ts.service;

import ts.dao.CustomerDAO;
import ts.dao.MeasurementDAO;
import ts.model.Customer;
import ts.model.Measurement;
import ts.util.DateFormatter;
import java.sql.Date;
import java.util.List;

public class CustomerService {
    private CustomerDAO customerDAO;
    private MeasurementDAO measurementDAO;
    
    public CustomerService() {
        this.customerDAO = new CustomerDAO();
        this.measurementDAO = new MeasurementDAO();
    }
    
    public boolean createCustomer(Customer customer, Measurement measurement) {
        // Validation
        if (customer.getName() == null || customer.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال اسم العميل");
        }
        if (customer.getPhone() == null || customer.getPhone().trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال رقم التليفون");
        }
        if (customer.getCustomerCode() == null || customer.getCustomerCode().trim().isEmpty()) {
            throw new IllegalArgumentException("يرجى إدخال كود العميل");
        }
        
        // Check if customer code already exists
        if (customerDAO.customerCodeExists(customer.getCustomerCode().trim())) {
            throw new IllegalArgumentException("كود العميل موجود بالفعل");
        }
        
        // Create customer
        boolean customerCreated = customerDAO.createCustomer(customer);
        
        // Create measurement if provided and customer was created successfully
        if (customerCreated && measurement != null) {
            measurement.setCustomerId(customer.getCustomerId());
            measurementDAO.createMeasurement(measurement);
        }
        
        return customerCreated;
    }
    
    public Customer getCustomerById(int customerId) {
        return customerDAO.getCustomerById(customerId);
    }
    
    public Customer getCustomerByCode(String customerCode) {
        return customerDAO.getCustomerByCode(customerCode);
    }
    
    public List<Customer> getAllCustomers() {
        return customerDAO.getAllCustomers();
    }
    
    public List<Customer> searchCustomers(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllCustomers();
        }
        return customerDAO.searchCustomers(searchTerm.trim());
    }
    
    public boolean updateCustomer(Customer customer) {
        return customerDAO.updateCustomer(customer);
    }
    
    public boolean deleteCustomer(int customerId) {
        return customerDAO.deleteCustomer(customerId);
    }
    
    public String generateNextCustomerCode() {
        return customerDAO.generateNextCustomerCode();
    }
    
    public Measurement getCustomerMeasurement(int customerId) {
        return measurementDAO.getMeasurementByCustomerId(customerId);
    }
    
    public boolean updateMeasurement(Measurement measurement) {
        return measurementDAO.updateMeasurement(measurement);
    }
    
    public Date parseDate(String dateStr) {
        return DateFormatter.parseDate(dateStr);
    }
    
    /**
     * Search customers by name or phone
     * @param searchTerm Search term (name or phone)
     * @return Customer object or null if not found
     */
    public Customer searchCustomerByNameOrPhone(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return null;
        }
        
        List<Customer> customers = customerDAO.searchCustomers(searchTerm.trim());
        return customers.isEmpty() ? null : customers.get(0);
    }
}

