package ts;

import java.awt.Component;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class FontManager {

    private static final Map<String, String> FONT_PATHS = createFontPathMap();
    private static final Map<String, String> WEIGHT_ALIASES = createAliasMap();
    private static final Map<String, Font> FONT_CACHE = new HashMap<>();

    private FontManager() {
    }

    public static Font getMontserrat(String weight, float size) {
        return getMontserrat(weight, Font.PLAIN, size);
    }

    public static Font getMontserrat(String weight, int style, float size) {
        Font base = loadMontserrat(weight);
        if (base != null) {
            return base.deriveFont(style, size);
        }
        return new Font("SansSerif", style, Math.round(size));
    }

    public static void applyMontserrat(Component component, String weight, float size) {
        if (component != null) {
            component.setFont(getMontserrat(weight, size));
        }
    }

    private static Font loadMontserrat(String requestedWeight) {
        String canonicalWeight = canonicalWeight(requestedWeight);
        String resourcePath = FONT_PATHS.get(canonicalWeight);
        if (resourcePath == null) {
            return null;
        }

        return FONT_CACHE.computeIfAbsent(resourcePath, path -> {
            try (InputStream stream = FontManager.class.getResourceAsStream(path)) {
                if (stream == null) {
                    System.err.println("Montserrat font resource not found: " + path);
                    return null;
                }
                Font font = Font.createFont(Font.TRUETYPE_FONT, stream);
                GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(font);
                return font;
            } catch (FontFormatException | IOException ex) {
                System.err.println("Failed to load Montserrat font (" + path + "): " + ex.getMessage());
                return null;
            }
        });
    }

    private static String canonicalWeight(String weight) {
        if (weight == null || weight.trim().isEmpty()) {
            return "Regular";
        }
        String normalized = weight.trim().toLowerCase(Locale.ROOT);
        return WEIGHT_ALIASES.getOrDefault(normalized, "Regular");
    }

    private static Map<String, String> createFontPathMap() {
        Map<String, String> paths = new HashMap<>();
        paths.put("ExtraBold", "/ts/fonts/alfont_com_Montserrat-Arabic-ExtraBold.ttf");
        paths.put("SemiBold", "/ts/fonts/alfont_com_Montserrat-Arabic-SemiBold.ttf");
        paths.put("Regular", "/ts/fonts/alfont_com_Montserrat-Arabic-Regular.ttf");
        paths.put("ExtraLight", "/ts/fonts/alfont_com_Montserrat-Arabic-ExtraLight.ttf");
        paths.put("Black", "/ts/fonts/alfont_com_Montserrat-Arabic-Black.ttf");
        return paths;
    }

    private static Map<String, String> createAliasMap() {
        Map<String, String> aliases = new HashMap<>();
        aliases.put("extrabold", "ExtraBold");
        aliases.put("bold", "SemiBold");
        aliases.put("semibold", "SemiBold");
        aliases.put("medium", "Regular");
        aliases.put("regular", "Regular");
        aliases.put("light", "ExtraLight");
        aliases.put("extralight", "ExtraLight");
        aliases.put("black", "Black");
        aliases.put("heavy", "Black");
        aliases.put("normal", "Regular");
        return aliases;
    }
}

