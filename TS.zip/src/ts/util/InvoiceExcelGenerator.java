package ts.util;

import ts.model.Invoice;
import ts.service.InvoiceService;
import ts.service.ReportService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.awt.Desktop;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generator for Pending Customers Excel Report
 * Uses Apache POI to create Excel files with proper Arabic text support
 */
public class InvoiceExcelGenerator {
    
    // RGB colors - Navy Blue, White, and Beige theme
    private static final byte[] NAVY_BLUE_RGB = {0, 51, 102};           // كحلي غامق
    private static final byte[] LIGHT_BEIGE_RGB = {(byte) 245, (byte) 245, (byte) 220};  // لبني فاتح
    private static final byte[] BEIGE_RGB = {(byte) 222, (byte) 184, (byte) 135};        // بيج
    private static final byte[] DARK_RED_RGB = {(byte) 139, 0, 0};      // أحمر غامق للمبالغ
    
    /**
     * Generate Excel report for all customers with pending amounts
     * @return Path to generated Excel file
     */
    public static String generatePendingCustomersReportExcel() throws Exception {
        // Get data from services
        ReportService reportService = new ReportService();
        InvoiceService invoiceService = new InvoiceService();
        
        // Get all invoices to check for incomplete orders
        List<Invoice> allInvoices = invoiceService.getAllInvoices();
        
        // Group by customer: incomplete invoices (regardless of payment) OR unpaid invoices
        Map<Integer, List<Invoice>> customerInvoicesMap = allInvoices.stream()
            .filter(invoice -> 
                !invoice.getStatus().equals("مكتمل") ||  // غير مكتمل (طلب لسه مش جاهز)
                invoice.getRemainingAmount().compareTo(BigDecimal.ZERO) > 0  // عليه فلوس
            )
            .collect(Collectors.groupingBy(Invoice::getCustomerId));
        
        // Get customer details for those with incomplete or unpaid invoices
        List<Map<String, Object>> allCustomers = reportService.getAllCustomersSummary();
        List<Map<String, Object>> customersWithPending = allCustomers.stream()
            .filter(customer -> {
                int customerId = (Integer) customer.get("customer_id");
                return customerInvoicesMap.containsKey(customerId);
            })
            .collect(Collectors.toList());
        
        // Get dashboard statistics
        Map<String, Object> stats = reportService.getDashboardStatistics();
        
        // Create output directory if it doesn't exist
        File outputDir = new File("reports_excel");
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        
        // Generate filename with timestamp
        String timestamp = String.valueOf(System.currentTimeMillis());
        String filename = "reports_excel/PendingCustomers_" + timestamp + ".xlsx";
        
        // Create workbook and sheet
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("تقرير العملاء");
        
        // Set RTL for the sheet (right-to-left for Arabic)
        sheet.setRightToLeft(true);
        
        int rowNum = 0;
        
        // Add title
        rowNum = addTitle(workbook, sheet, rowNum);
        
        // Add date
        rowNum = addDate(workbook, sheet, rowNum);
        
        // Add empty row
        rowNum++;
        
        // Check if there are customers with pending amounts
        if (customersWithPending.isEmpty()) {
            addNoDataMessage(workbook, sheet, rowNum);
        } else {
            // Add table header
            rowNum = addTableHeader(workbook, sheet, rowNum);
            
            // Add customer rows with their invoices
            for (Map<String, Object> customer : customersWithPending) {
                int customerId = (Integer) customer.get("customer_id");
                String customerName = (String) customer.get("name");
                String customerPhone = (String) customer.get("phone");
                BigDecimal totalRemaining = (BigDecimal) customer.get("total_remaining");
                
                // Add customer main row
                rowNum = addCustomerRow(workbook, sheet, rowNum, customerName, customerPhone, totalRemaining);
                
                // Get customer invoices that are not completed (regardless of payment)
                List<Invoice> incompleteInvoices = customerInvoicesMap.getOrDefault(customerId, new java.util.ArrayList<>());
                
                // Add invoice detail rows
                for (Invoice invoice : incompleteInvoices) {
                    rowNum = addInvoiceDetailRow(workbook, sheet, rowNum, invoice);
                }
                
                // Add empty row as separator
                rowNum++;
            }
        }
        
        // Add statistics section
        rowNum += 2; // Add some spacing
        rowNum = addStatisticsSection(workbook, sheet, rowNum, stats);
        
        // Auto-size columns
        for (int i = 0; i < 4; i++) {
            sheet.autoSizeColumn(i);
            // Add extra width for better readability
            sheet.setColumnWidth(i, sheet.getColumnWidth(i) + 1000);
        }
        
        // Write to file
        try (FileOutputStream fileOut = new FileOutputStream(filename)) {
            workbook.write(fileOut);
        }
        
        workbook.close();
        
        return filename;
    }
    
    /**
     * Add title row to the sheet
     */
    private static int addTitle(Workbook workbook, Sheet sheet, int rowNum) {
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(0);
        cell.setCellValue("تقرير العملاء - الطلبات غير المكتملة");
        
        // Merge cells for title
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        // Apply title style
        CellStyle titleStyle = workbook.createCellStyle();
        Font titleFont = workbook.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 18);
        titleStyle.setFont(titleFont);
        titleStyle.setAlignment(HorizontalAlignment.CENTER);
        titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        
        cell.setCellStyle(titleStyle);
        row.setHeightInPoints(30);
        
        return rowNum;
    }
    
    /**
     * Add date row to the sheet
     */
    private static int addDate(Workbook workbook, Sheet sheet, int rowNum) {
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(0);
        cell.setCellValue("التاريخ: " + DateFormatter.getCurrentDateString());
        
        // Merge cells for date
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        // Apply date style
        CellStyle dateStyle = workbook.createCellStyle();
        Font dateFont = workbook.createFont();
        dateFont.setFontHeightInPoints((short) 10);
        dateStyle.setFont(dateFont);
        dateStyle.setAlignment(HorizontalAlignment.CENTER);
        
        cell.setCellStyle(dateStyle);
        
        return rowNum;
    }
    
    /**
     * Add "no data" message
     */
    private static void addNoDataMessage(Workbook workbook, Sheet sheet, int rowNum) {
        Row row = sheet.createRow(rowNum);
        Cell cell = row.createCell(0);
        cell.setCellValue("لا يوجد طلبات غير مكتملة حالياً");
        
        // Merge cells
        sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 3));
        
        // Apply style
        CellStyle noDataStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        font.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        noDataStyle.setFont(font);
        noDataStyle.setAlignment(HorizontalAlignment.CENTER);
        
        cell.setCellStyle(noDataStyle);
    }
    
    /**
     * Add table header row
     */
    private static int addTableHeader(Workbook workbook, Sheet sheet, int rowNum) {
        Row headerRow = sheet.createRow(rowNum++);
        
        String[] headers = {"اسم العميل", "رقم الهاتف", "الفاتورة", "المتبقي"};
        
        // Create header style with Navy Blue background
        XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
        XSSFFont headerFont = (XSSFFont) workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerFont.setFontHeightInPoints((short) 11);
        headerStyle.setFont(headerFont);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headerStyle.setFillForegroundColor(new XSSFColor(NAVY_BLUE_RGB, null));
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        // Add borders
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        
        // Create header cells
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        headerRow.setHeightInPoints(25);
        
        return rowNum;
    }
    
    /**
     * Add customer main row
     */
    private static int addCustomerRow(Workbook workbook, Sheet sheet, int rowNum,
                                     String name, String phone, BigDecimal totalRemaining) {
        Row row = sheet.createRow(rowNum++);
        
        // Create customer style (light beige background)
        XSSFCellStyle customerStyle = (XSSFCellStyle) workbook.createCellStyle();
        Font customerFont = workbook.createFont();
        customerFont.setBold(true);
        customerFont.setFontHeightInPoints((short) 11);
        customerStyle.setFont(customerFont);
        customerStyle.setAlignment(HorizontalAlignment.CENTER);
        customerStyle.setFillForegroundColor(new XSSFColor(LIGHT_BEIGE_RGB, null));
        customerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        customerStyle.setBorderBottom(BorderStyle.THIN);
        customerStyle.setBorderTop(BorderStyle.THIN);
        customerStyle.setBorderLeft(BorderStyle.THIN);
        customerStyle.setBorderRight(BorderStyle.THIN);
        
        // Customer name
        Cell nameCell = row.createCell(0);
        nameCell.setCellValue(name);
        nameCell.setCellStyle(customerStyle);
        
        // Phone
        Cell phoneCell = row.createCell(1);
        phoneCell.setCellValue(phone);
        CellStyle phoneStyle = workbook.createCellStyle();
        phoneStyle.cloneStyleFrom(customerStyle);
        Font phoneFont = workbook.createFont();
        phoneFont.setFontHeightInPoints((short) 10);
        phoneStyle.setFont(phoneFont);
        phoneCell.setCellStyle(phoneStyle);
        
        // Empty cell for invoice column
        Cell emptyCell = row.createCell(2);
        emptyCell.setCellValue("");
        emptyCell.setCellStyle(customerStyle);
        
        // Total remaining (dark red color)
        Cell totalCell = row.createCell(3);
        totalCell.setCellValue(totalRemaining + " جنيه");
        XSSFCellStyle totalStyle = (XSSFCellStyle) workbook.createCellStyle();
        totalStyle.cloneStyleFrom(customerStyle);
        XSSFFont totalFont = (XSSFFont) workbook.createFont();
        totalFont.setBold(true);
        totalFont.setColor(new XSSFColor(DARK_RED_RGB, null));
        totalFont.setFontHeightInPoints((short) 11);
        totalStyle.setFont(totalFont);
        totalCell.setCellStyle(totalStyle);
        
        return rowNum;
    }
    
    /**
     * Add invoice detail row
     */
    private static int addInvoiceDetailRow(Workbook workbook, Sheet sheet, int rowNum, Invoice invoice) {
        Row row = sheet.createRow(rowNum++);
        
        // Create detail style
        CellStyle detailStyle = workbook.createCellStyle();
        Font detailFont = workbook.createFont();
        detailFont.setFontHeightInPoints((short) 9);
        detailStyle.setFont(detailFont);
        detailStyle.setAlignment(HorizontalAlignment.RIGHT);
        detailStyle.setBorderBottom(BorderStyle.HAIR);
        detailStyle.setBorderLeft(BorderStyle.HAIR);
        detailStyle.setBorderRight(BorderStyle.HAIR);
        
        // Empty cells for customer name and phone (indent effect)
        Cell emptyCell1 = row.createCell(0);
        emptyCell1.setCellValue("");
        emptyCell1.setCellStyle(detailStyle);
        
        Cell emptyCell2 = row.createCell(1);
        emptyCell2.setCellValue("");
        emptyCell2.setCellStyle(detailStyle);
        
        // Invoice details
        String invoiceInfo = invoice.getInvoiceNumber() + "\n" +
                           "دفع: " + invoice.getPaidAmount() + " جنيه\n" +
                           "تاريخ التسليم: " + 
                           (invoice.getDeliveryDate() != null ? DateFormatter.formatDate(invoice.getDeliveryDate()) : "غير محدد");
        
        Cell invoiceCell = row.createCell(2);
        invoiceCell.setCellValue(invoiceInfo);
        CellStyle invoiceStyle = workbook.createCellStyle();
        invoiceStyle.cloneStyleFrom(detailStyle);
        invoiceStyle.setWrapText(true);
        invoiceCell.setCellStyle(invoiceStyle);
        
        // Remaining amount for this invoice (dark red)
        Cell remainingCell = row.createCell(3);
        remainingCell.setCellValue(invoice.getRemainingAmount() + " جنيه");
        CellStyle remainingStyle = workbook.createCellStyle();
        remainingStyle.cloneStyleFrom(detailStyle);
        remainingStyle.setAlignment(HorizontalAlignment.CENTER);
        XSSFFont remainingFont = (XSSFFont) workbook.createFont();
        remainingFont.setColor(new XSSFColor(DARK_RED_RGB, null));
        remainingFont.setFontHeightInPoints((short) 9);
        remainingStyle.setFont(remainingFont);
        remainingCell.setCellStyle(remainingStyle);
        
        row.setHeightInPoints(45);
        
        return rowNum;
    }
    
    /**
     * Add statistics section
     */
    private static int addStatisticsSection(Workbook workbook, Sheet sheet, int rowNum,
                                           Map<String, Object> stats) {
        // Add statistics title
        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("الإحصائيات");
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        CellStyle statsTitleStyle = workbook.createCellStyle();
        Font statsTitleFont = workbook.createFont();
        statsTitleFont.setBold(true);
        statsTitleFont.setFontHeightInPoints((short) 16);
        statsTitleStyle.setFont(statsTitleFont);
        statsTitleStyle.setAlignment(HorizontalAlignment.CENTER);
        titleCell.setCellStyle(statsTitleStyle);
        titleRow.setHeightInPoints(25);
        
        rowNum++; // Empty row
        
        // Create statistics data
        String[][] statsData = {
            {"المتبقي تحصيله", stats.get("total_remaining") + " جنيه"},
            {"الإيرادات اليوم", stats.get("today_revenue") + " جنيه"},
            {"الفواتير النشطة", stats.get("active_invoices").toString()},
            {"إجمالي العملاء", stats.get("total_customers").toString()}
        };
        
        // Create styles for statistics
        CellStyle statLabelStyle = workbook.createCellStyle();
        Font labelFont = workbook.createFont();
        labelFont.setFontHeightInPoints((short) 10);
        labelFont.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        statLabelStyle.setFont(labelFont);
        statLabelStyle.setAlignment(HorizontalAlignment.RIGHT);
        
        CellStyle statValueStyle = workbook.createCellStyle();
        XSSFFont valueFont = (XSSFFont) workbook.createFont();
        valueFont.setBold(true);
        valueFont.setFontHeightInPoints((short) 14);
        valueFont.setColor(new XSSFColor(NAVY_BLUE_RGB, null));
        statValueStyle.setFont(valueFont);
        statValueStyle.setAlignment(HorizontalAlignment.RIGHT);
        
        // Add statistics rows
        for (String[] stat : statsData) {
            Row row = sheet.createRow(rowNum++);
            
            // Label
            Cell labelCell = row.createCell(1);
            labelCell.setCellValue(stat[0]);
            labelCell.setCellStyle(statLabelStyle);
            
            // Value
            Cell valueCell = row.createCell(0);
            valueCell.setCellValue(stat[1]);
            valueCell.setCellStyle(statValueStyle);
            
            row.setHeightInPoints(20);
        }
        
        return rowNum;
    }
    
    /**
     * Generate and open Excel report for pending customers
     */
    public static void generateAndOpenPendingCustomersReportExcel() {
        try {
            String filename = generatePendingCustomersReportExcel();
            
            // Open the Excel file
            if (Desktop.isDesktopSupported()) {
                File excelFile = new File(filename);
                Desktop.getDesktop().open(excelFile);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Could not create Excel file - " + e.getMessage());
            throw new RuntimeException("فشل في إنشاء ملف Excel: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error generating Excel: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("خطأ في إنشاء Excel: " + e.getMessage());
        }
    }
}


