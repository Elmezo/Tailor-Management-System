package ts.util;

/**
 * Interface for components that need to refresh data
 */
public interface DataRefreshListener {
    /**
     * Called when data needs to be refreshed
     */
    void refreshData();
}

