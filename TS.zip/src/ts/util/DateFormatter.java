package ts.util;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Utility class for date formatting and parsing
 */
public class DateFormatter {
    private static final String DATE_FORMAT = "dd-MM-yyyy";
    private static final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
    
    /**
     * Parse a date string in format dd-MM-yyyy
     * @param dateStr Date string to parse
     * @return SQL Date object
     * @throws IllegalArgumentException if date format is invalid
     */
    public static Date parseDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return null;
        }
        try {
            java.util.Date parsed = sdf.parse(dateStr.trim());
            return new Date(parsed.getTime());
        } catch (ParseException e) {
            throw new IllegalArgumentException("صيغة التاريخ غير صحيحة. يجب أن تكون بصيغة: يوم-شهر-سنة (مثال: 12-10-2000)");
        }
    }
    
    /**
     * Format a SQL Date to string in format dd-MM-yyyy
     * @param date SQL Date object
     * @return Formatted date string
     */
    public static String formatDate(Date date) {
        if (date == null) {
            return "";
        }
        return sdf.format(date);
    }
    
    /**
     * Get current date
     * @return Current date as SQL Date
     */
    public static Date getCurrentDate() {
        return new Date(System.currentTimeMillis());
    }
    
    /**
     * Get current date formatted as string
     * @return Current date as formatted string
     */
    public static String getCurrentDateString() {
        return formatDate(getCurrentDate());
    }
}

