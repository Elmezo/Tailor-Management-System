package ts.database;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {
    
    /**
     * تهيئة قاعدة البيانات وإنشاء الجداول إذا لم تكن موجودة
     */
    public static void initialize(Connection connection) {
        try {
            if (!isDatabaseInitialized(connection)) {
                System.out.println("قاعدة البيانات جديدة، جاري إنشاء الجداول...");
                createTables(connection);
                createViews(connection);
                insertDefaultData(connection);
                System.out.println("تم إنشاء الجداول بنجاح!");
            } else {
                System.out.println("قاعدة البيانات موجودة بالفعل");
            }
        } catch (SQLException e) {
            System.err.println("خطأ في تهيئة قاعدة البيانات: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * التحقق من وجود الجداول الأساسية
     */
    private static boolean isDatabaseInitialized(Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery(
            "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'USERS'"
        );
        rs.next();
        int count = rs.getInt("count");
        rs.close();
        stmt.close();
        return count > 0;
    }
    
    /**
     * إنشاء الجداول الأساسية
     */
    private static void createTables(Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        
        // جدول المستخدمين
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS users (" +
            "  user_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  username VARCHAR(50) NOT NULL UNIQUE," +
            "  password VARCHAR(255) NOT NULL," +
            "  full_name VARCHAR(100) NOT NULL," +
            "  phone VARCHAR(20) NOT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_username ON users(username)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_phone ON users(phone)");
        
        // جدول العملاء
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS customers (" +
            "  customer_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  customer_code VARCHAR(50) NOT NULL UNIQUE," +
            "  name VARCHAR(100) NOT NULL," +
            "  phone VARCHAR(20) NOT NULL," +
            "  delivery_date DATE NOT NULL," +
            "  receive_date DATE NOT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_customer_code ON customers(customer_code)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_name ON customers(name)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_phone_cust ON customers(phone)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_delivery_date ON customers(delivery_date)");
        
        // جدول الفواتير
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS invoices (" +
            "  invoice_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  invoice_number VARCHAR(50) NOT NULL UNIQUE," +
            "  customer_id INT NOT NULL," +
            "  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00," +
            "  paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00," +
            "  remaining_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00," +
            "  status VARCHAR(50) NOT NULL DEFAULT 'غير مكتمل'," +
            "  delivery_status VARCHAR(50) NOT NULL DEFAULT 'لم يتم التسليم'," +
            "  delivery_payment_status VARCHAR(50) DEFAULT NULL," +
            "  delivery_date DATE NOT NULL," +
            "  receive_date DATE NOT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP," +
            "  CONSTRAINT chk_remaining_not_negative CHECK (remaining_amount >= 0)," +
            "  CONSTRAINT chk_total_amount_not_negative CHECK (total_amount >= 0)," +
            "  CONSTRAINT chk_paid_amount_not_negative CHECK (paid_amount >= 0)," +
            "  CONSTRAINT invoices_ibfk_1 FOREIGN KEY (customer_id) REFERENCES customers(customer_id)" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_invoice_number ON invoices(invoice_number)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_customer_id_inv ON invoices(customer_id)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_status ON invoices(status)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_delivery_date_inv ON invoices(delivery_date)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_receive_date ON invoices(receive_date)");
        
        // جدول القياسات الخاصة بالفواتير
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS invoice_measurements (" +
            "  invoice_measurement_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  invoice_id INT NOT NULL," +
            "  pants_type VARCHAR(50) DEFAULT NULL," +
            "  pants_length VARCHAR(50) DEFAULT NULL," +
            "  leg VARCHAR(50) DEFAULT NULL," +
            "  leg_type VARCHAR(50) DEFAULT NULL," +
            "  detail VARCHAR(50) DEFAULT NULL," +
            "  length VARCHAR(50) DEFAULT NULL," +
            "  sleeve VARCHAR(50) DEFAULT NULL," +
            "  safra VARCHAR(50) DEFAULT NULL," +
            "  pocket VARCHAR(50) DEFAULT NULL," +
            "  bshleik VARCHAR(50) DEFAULT NULL," +
            "  fit VARCHAR(100) DEFAULT NULL," +
            "  atk VARCHAR(100) DEFAULT NULL," +
            "  location VARCHAR(50) DEFAULT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  CONSTRAINT invoice_measurements_ibfk_1 FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_invoice_id_meas ON invoice_measurements(invoice_id)");
        
        // جدول القياسات العامة
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS measurements (" +
            "  measurement_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  customer_id INT NOT NULL," +
            "  pants_type VARCHAR(50) DEFAULT NULL," +
            "  pants_length VARCHAR(50) DEFAULT NULL," +
            "  leg VARCHAR(50) DEFAULT NULL," +
            "  leg_type VARCHAR(50) DEFAULT NULL," +
            "  detail VARCHAR(50) DEFAULT NULL," +
            "  length VARCHAR(50) DEFAULT NULL," +
            "  sleeve VARCHAR(50) DEFAULT NULL," +
            "  safra VARCHAR(50) DEFAULT NULL," +
            "  pocket VARCHAR(50) DEFAULT NULL," +
            "  bshleik VARCHAR(50) DEFAULT NULL," +
            "  fit VARCHAR(100) DEFAULT NULL," +
            "  atk VARCHAR(100) DEFAULT NULL," +
            "  location VARCHAR(50) DEFAULT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP," +
            "  CONSTRAINT measurements_ibfk_1 FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_customer_id_meas ON measurements(customer_id)");
        
        // جدول المدفوعات
        stmt.executeUpdate(
            "CREATE TABLE IF NOT EXISTS payments (" +
            "  payment_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY," +
            "  invoice_id INT NOT NULL," +
            "  amount DECIMAL(10,2) NOT NULL," +
            "  payment_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  notes TEXT DEFAULT NULL," +
            "  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP," +
            "  CONSTRAINT payments_ibfk_1 FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE" +
            ")"
        );
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_invoice_id_pay ON payments(invoice_id)");
        stmt.executeUpdate("CREATE INDEX IF NOT EXISTS idx_payment_date ON payments(payment_date)");
        
        stmt.close();
        System.out.println("تم إنشاء جميع الجداول بنجاح");
    }
    
    /**
     * إنشاء الـ Views
     */
    private static void createViews(Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        
        // View لتفاصيل الفواتير
        stmt.executeUpdate(
            "CREATE OR REPLACE VIEW invoice_details AS " +
            "SELECT i.invoice_id, i.invoice_number, c.customer_id, c.name AS customer_name, " +
            "c.phone AS customer_phone, i.total_amount, i.paid_amount, i.remaining_amount, " +
            "i.status, i.delivery_status, i.delivery_payment_status, i.delivery_date, " +
            "i.receive_date, i.created_at " +
            "FROM invoices i " +
            "JOIN customers c ON i.customer_id = c.customer_id"
        );
        
        // View لملخص العملاء
        stmt.executeUpdate(
            "CREATE OR REPLACE VIEW customer_summary AS " +
            "SELECT c.customer_id, c.customer_code, c.name, c.phone, " +
            "COUNT(i.invoice_id) AS total_invoices, " +
            "COALESCE(SUM(i.total_amount), 0) AS total_amount, " +
            "COALESCE(SUM(i.paid_amount), 0) AS total_paid, " +
            "COALESCE(SUM(i.remaining_amount), 0) AS total_remaining, " +
            "COUNT(CASE WHEN i.status = 'غير مكتمل' THEN 1 END) AS incomplete_invoices " +
            "FROM customers c " +
            "LEFT JOIN invoices i ON c.customer_id = i.customer_id " +
            "GROUP BY c.customer_id, c.customer_code, c.name, c.phone " +
            "ORDER BY COALESCE(SUM(i.remaining_amount), 0) DESC"
        );
        
        // View للفواتير القادمة
        stmt.executeUpdate(
            "CREATE OR REPLACE VIEW upcoming_invoices AS " +
            "SELECT i.invoice_id, i.invoice_number, i.receive_date, c.name AS customer_name, " +
            "c.phone AS customer_phone, i.total_amount, i.remaining_amount, i.status, " +
            "DATEDIFF(i.receive_date, CURRENT_DATE) AS days_until_receive " +
            "FROM invoices i " +
            "JOIN customers c ON i.customer_id = c.customer_id " +
            "WHERE i.status = 'غير مكتمل' AND i.receive_date >= CURRENT_DATE " +
            "ORDER BY i.receive_date ASC"
        );
        
        stmt.close();
        System.out.println("تم إنشاء الـ Views بنجاح");
    }
    
    /**
     * إدراج البيانات الافتراضية
     */
    private static void insertDefaultData(Connection connection) throws SQLException {
        Statement stmt = connection.createStatement();
        
        // إضافة مستخدم افتراضي (admin)
        stmt.executeUpdate(
            "INSERT INTO users (username, password, full_name, phone) " +
            "VALUES ('admin', 'admin123', 'مدير النظام', '01114493323')"
        );
        
        stmt.close();
        System.out.println("تم إدراج البيانات الافتراضية");
    }
}

