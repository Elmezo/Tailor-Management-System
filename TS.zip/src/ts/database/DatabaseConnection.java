package ts.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;
    
    private DatabaseConnection() {
        try {
            // تحديد Driver بناءً على نوع قاعدة البيانات
            String dbType = DatabaseConfig.getDatabaseType();
            if ("h2".equalsIgnoreCase(dbType)) {
                Class.forName("org.h2.Driver");
                System.out.println("تم تحميل H2 Driver");
            } else {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("تم تحميل MySQL Driver");
            }
            
            this.connection = DriverManager.getConnection(
                DatabaseConfig.getUrl(),
                DatabaseConfig.getUsername(),
                DatabaseConfig.getPassword()
            );
            System.out.println("تم الاتصال بقاعدة البيانات بنجاح (" + dbType + ")");
            
            // إنشاء الجداول إذا كانت قاعدة البيانات جديدة (H2)
            if ("h2".equalsIgnoreCase(dbType)) {
                DatabaseInitializer.initialize(connection);
            }
        } catch (ClassNotFoundException e) {
            System.err.println("خطأ في تحميل Database Driver: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("خطأ في الاتصال بقاعدة البيانات: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static DatabaseConnection getInstance() {
        if (instance == null || !isConnectionValid()) {
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    private static boolean isConnectionValid() {
        try {
            return instance != null && 
                   instance.connection != null && 
                   !instance.connection.isClosed() &&
                   instance.connection.isValid(2);
        } catch (SQLException e) {
            return false;
        }
    }
    
    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(
                    DatabaseConfig.getUrl(),
                    DatabaseConfig.getUsername(),
                    DatabaseConfig.getPassword()
                );
            }
        } catch (SQLException e) {
            System.err.println("خطأ في إعادة الاتصال بقاعدة البيانات: " + e.getMessage());
            e.printStackTrace();
        }
        return connection;
    }
    
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("تم قطع الاتصال بقاعدة البيانات");
            }
        } catch (SQLException e) {
            System.err.println("خطأ في قطع الاتصال: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

