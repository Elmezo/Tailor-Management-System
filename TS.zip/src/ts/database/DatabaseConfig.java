package ts.database;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DatabaseConfig {
    private static Properties props = new Properties();
    private static String dbType = "h2";
    
    static {
        loadProperties();
    }
    
    private static void loadProperties() {
        try (InputStream input = new FileInputStream("config/database.properties")) {
            props.load(input);
            dbType = props.getProperty("db.type", "h2");
            System.out.println("تم تحميل إعدادات قاعدة البيانات: " + dbType);
        } catch (IOException e) {
            System.err.println("تعذر تحميل ملف الإعدادات، سيتم استخدام H2 افتراضياً");
            // استخدام القيم الافتراضية لـ H2
            props.setProperty("db.type", "h2");
            props.setProperty("db.h2.path", "./data/tailor_shop_db");
            props.setProperty("db.h2.username", "sa");
            props.setProperty("db.h2.password", "");
            dbType = "h2";
        }
    }
    
    public static String getUrl() {
        if ("h2".equalsIgnoreCase(dbType)) {
            String dbPath = props.getProperty("db.h2.path", "./data/tailor_shop_db");
            // MODE=MySQL لتوافق أفضل مع MySQL syntax
            // AUTO_SERVER=TRUE للسماح بالاتصالات المتعددة
            return String.format("jdbc:h2:%s;AUTO_SERVER=TRUE;MODE=MySQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=FALSE", 
                               dbPath);
        } else {
            // MySQL fallback
            String host = props.getProperty("db.mysql.host", "localhost");
            String port = props.getProperty("db.mysql.port", "3306");
            String database = props.getProperty("db.mysql.database", "tailor_shop_db");
            return String.format("jdbc:mysql://%s:%s/%s?useSSL=false&serverTimezone=UTC&characterEncoding=utf8", 
                               host, port, database);
        }
    }
    
    public static String getUsername() {
        if ("h2".equalsIgnoreCase(dbType)) {
            return props.getProperty("db.h2.username", "sa");
        } else {
            return props.getProperty("db.mysql.username", "root");
        }
    }
    
    public static String getPassword() {
        if ("h2".equalsIgnoreCase(dbType)) {
            return props.getProperty("db.h2.password", "");
        } else {
            return props.getProperty("db.mysql.password", "");
        }
    }
    
    public static String getDatabaseType() {
        return dbType;
    }
}

