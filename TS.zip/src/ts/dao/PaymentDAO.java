package ts.dao;

import ts.database.DatabaseConnection;
import ts.model.Payment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    private Connection connection;
    
    public PaymentDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    public boolean createPayment(Payment payment) {
        String sql = "INSERT INTO payments (invoice_id, amount, notes) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, payment.getInvoiceId());
            stmt.setBigDecimal(2, payment.getAmount());
            stmt.setString(3, payment.getNotes());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        payment.setPaymentId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("خطأ في إنشاء الدفعة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public Payment getPaymentById(int paymentId) {
        String sql = "SELECT * FROM payments WHERE payment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, paymentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractPaymentFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الدفعة: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Payment> getPaymentsByInvoiceId(int invoiceId) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    payments.add(extractPaymentFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الدفعات: " + e.getMessage());
            e.printStackTrace();
        }
        return payments;
    }
    
    public List<Payment> getAllPayments() {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments ORDER BY payment_date DESC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                payments.add(extractPaymentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الدفعات: " + e.getMessage());
            e.printStackTrace();
        }
        return payments;
    }
    
    public List<Payment> getPaymentsByDate(java.sql.Date date) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE DATE(payment_date) = ? ORDER BY payment_date DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, date);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    payments.add(extractPaymentFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع دفعات اليوم: " + e.getMessage());
            e.printStackTrace();
        }
        return payments;
    }
    
    public boolean deletePayment(int paymentId) {
        String sql = "DELETE FROM payments WHERE payment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, paymentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في حذف الدفعة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    private Payment extractPaymentFromResultSet(ResultSet rs) throws SQLException {
        Payment payment = new Payment();
        payment.setPaymentId(rs.getInt("payment_id"));
        payment.setInvoiceId(rs.getInt("invoice_id"));
        payment.setAmount(rs.getBigDecimal("amount"));
        payment.setPaymentDate(rs.getTimestamp("payment_date"));
        payment.setNotes(rs.getString("notes"));
        payment.setCreatedAt(rs.getTimestamp("created_at"));
        return payment;
    }
}

