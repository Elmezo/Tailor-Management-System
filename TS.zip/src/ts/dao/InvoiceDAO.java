package ts.dao;

import ts.database.DatabaseConnection;
import ts.model.Invoice;
import ts.model.Measurement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDAO {
    private Connection connection;
    
    public InvoiceDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    public boolean createInvoice(Invoice invoice) {
        String sql = "INSERT INTO invoices (invoice_number, customer_id, total_amount, paid_amount, remaining_amount, status, delivery_status, delivery_payment_status, delivery_date, receive_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, invoice.getInvoiceNumber());
            stmt.setInt(2, invoice.getCustomerId());
            stmt.setBigDecimal(3, invoice.getTotalAmount());
            stmt.setBigDecimal(4, invoice.getPaidAmount());
            stmt.setBigDecimal(5, invoice.getRemainingAmount());
            stmt.setString(6, invoice.getStatus());
            stmt.setString(7, invoice.getDeliveryStatus());
            stmt.setString(8, invoice.getDeliveryPaymentStatus());
            stmt.setDate(9, invoice.getDeliveryDate());
            stmt.setDate(10, invoice.getReceiveDate());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        invoice.setInvoiceId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("خطأ في إنشاء الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean createInvoiceMeasurement(int invoiceId, Measurement measurement) {
        String sql = "INSERT INTO invoice_measurements (invoice_id, pants_type, pants_length, leg, leg_type, detail, length, sleeve, safra, pocket, bshleik, fit, atk, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            stmt.setString(2, measurement.getPantsType());
            stmt.setString(3, measurement.getPantsLength());
            stmt.setString(4, measurement.getLeg());
            stmt.setString(5, measurement.getLegType());
            stmt.setString(6, measurement.getDetail());
            stmt.setString(7, measurement.getLength());
            stmt.setString(8, measurement.getSleeve());
            stmt.setString(9, measurement.getSafra());
            stmt.setString(10, measurement.getPocket());
            stmt.setString(11, measurement.getBshleik());
            stmt.setString(12, measurement.getFit());
            stmt.setString(13, measurement.getAtk());
            stmt.setString(14, measurement.getLocation());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في إنشاء مقاسات الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public Invoice getInvoiceById(int invoiceId) {
        String sql = "SELECT i.*, c.name as customer_name, c.phone as customer_phone FROM invoices i JOIN customers c ON i.customer_id = c.customer_id WHERE i.invoice_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractInvoiceFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public Invoice getInvoiceByNumber(String invoiceNumber) {
        String sql = "SELECT i.*, c.name as customer_name, c.phone as customer_phone FROM invoices i JOIN customers c ON i.customer_id = c.customer_id WHERE i.invoice_number = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, invoiceNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractInvoiceFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Invoice> getAllInvoices() {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT i.*, c.name as customer_name, c.phone as customer_phone FROM invoices i JOIN customers c ON i.customer_id = c.customer_id ORDER BY i.created_at DESC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                invoices.add(extractInvoiceFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع الفواتير: " + e.getMessage());
            e.printStackTrace();
        }
        return invoices;
    }
    
    public List<Invoice> getInvoicesByCustomerId(int customerId) {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT i.*, c.name as customer_name, c.phone as customer_phone FROM invoices i JOIN customers c ON i.customer_id = c.customer_id WHERE i.customer_id = ? ORDER BY i.created_at DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    invoices.add(extractInvoiceFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع فواتير العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return invoices;
    }
    
    public List<Invoice> searchInvoices(String searchTerm) {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT i.*, c.name as customer_name, c.phone as customer_phone FROM invoices i JOIN customers c ON i.customer_id = c.customer_id WHERE i.invoice_number LIKE ? OR c.name LIKE ? ORDER BY i.created_at DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            String searchPattern = "%" + searchTerm + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    invoices.add(extractInvoiceFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في البحث عن الفواتير: " + e.getMessage());
            e.printStackTrace();
        }
        return invoices;
    }
    
    public boolean updateInvoice(Invoice invoice) {
        String sql = "UPDATE invoices SET total_amount = ?, paid_amount = ?, remaining_amount = ?, status = ?, delivery_status = ?, delivery_payment_status = ?, delivery_date = ?, receive_date = ?, updated_at = CURRENT_TIMESTAMP WHERE invoice_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setBigDecimal(1, invoice.getTotalAmount());
            stmt.setBigDecimal(2, invoice.getPaidAmount());
            stmt.setBigDecimal(3, invoice.getRemainingAmount());
            stmt.setString(4, invoice.getStatus());
            stmt.setString(5, invoice.getDeliveryStatus());
            stmt.setString(6, invoice.getDeliveryPaymentStatus());
            stmt.setDate(7, invoice.getDeliveryDate());
            stmt.setDate(8, invoice.getReceiveDate());
            stmt.setInt(9, invoice.getInvoiceId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في تحديث الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteInvoice(int invoiceId) {
        String sql = "DELETE FROM invoices WHERE invoice_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في حذف الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public String generateNextInvoiceNumber() {
        String sql = "SELECT invoice_number FROM invoices ORDER BY invoice_id DESC LIMIT 1";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                String lastNumber = rs.getString("invoice_number");
                // Extract number from INV-001 format
                String[] parts = lastNumber.split("-");
                if (parts.length == 2) {
                    int nextNumber = Integer.parseInt(parts[1]) + 1;
                    return String.format("INV-%03d", nextNumber);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في توليد رقم الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return "INV-001";
    }
    
    public Measurement getInvoiceMeasurement(int invoiceId) {
        String sql = "SELECT * FROM invoice_measurements WHERE invoice_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Measurement measurement = new Measurement();
                    measurement.setPantsType(rs.getString("pants_type"));
                    measurement.setPantsLength(rs.getString("pants_length"));
                    measurement.setLeg(rs.getString("leg"));
                    measurement.setLegType(rs.getString("leg_type"));
                    measurement.setDetail(rs.getString("detail"));
                    measurement.setLength(rs.getString("length"));
                    measurement.setSleeve(rs.getString("sleeve"));
                    measurement.setSafra(rs.getString("safra"));
                    measurement.setPocket(rs.getString("pocket"));
                    measurement.setBshleik(rs.getString("bshleik"));
                    measurement.setFit(rs.getString("fit"));
                    measurement.setAtk(rs.getString("atk"));
                    measurement.setLocation(rs.getString("location"));
                    return measurement;
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع مقاسات الفاتورة: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    private Invoice extractInvoiceFromResultSet(ResultSet rs) throws SQLException {
        Invoice invoice = new Invoice();
        invoice.setInvoiceId(rs.getInt("invoice_id"));
        invoice.setInvoiceNumber(rs.getString("invoice_number"));
        invoice.setCustomerId(rs.getInt("customer_id"));
        invoice.setTotalAmount(rs.getBigDecimal("total_amount"));
        invoice.setPaidAmount(rs.getBigDecimal("paid_amount"));
        invoice.setRemainingAmount(rs.getBigDecimal("remaining_amount"));
        invoice.setStatus(rs.getString("status"));
        invoice.setDeliveryStatus(rs.getString("delivery_status"));
        invoice.setDeliveryPaymentStatus(rs.getString("delivery_payment_status"));
        invoice.setDeliveryDate(rs.getDate("delivery_date"));
        invoice.setReceiveDate(rs.getDate("receive_date"));
        invoice.setCreatedAt(rs.getTimestamp("created_at"));
        invoice.setUpdatedAt(rs.getTimestamp("updated_at"));
        invoice.setCustomerName(rs.getString("customer_name"));
        invoice.setCustomerPhone(rs.getString("customer_phone"));
        return invoice;
    }
}

