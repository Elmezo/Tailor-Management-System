package ts.dao;

import ts.database.DatabaseConnection;
import ts.model.Measurement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MeasurementDAO {
    private Connection connection;
    
    public MeasurementDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    public boolean createMeasurement(Measurement measurement) {
        String sql = "INSERT INTO measurements (customer_id, pants_type, pants_length, leg, leg_type, detail, length, sleeve, safra, pocket, bshleik, fit, atk, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, measurement.getCustomerId());
            stmt.setString(2, measurement.getPantsType());
            stmt.setString(3, measurement.getPantsLength());
            stmt.setString(4, measurement.getLeg());
            stmt.setString(5, measurement.getLegType());
            stmt.setString(6, measurement.getDetail());
            stmt.setString(7, measurement.getLength());
            stmt.setString(8, measurement.getSleeve());
            stmt.setString(9, measurement.getSafra());
            stmt.setString(10, measurement.getPocket());
            stmt.setString(11, measurement.getBshleik());
            stmt.setString(12, measurement.getFit());
            stmt.setString(13, measurement.getAtk());
            stmt.setString(14, measurement.getLocation());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        measurement.setMeasurementId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("خطأ في إنشاء المقاسات: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public Measurement getMeasurementByCustomerId(int customerId) {
        String sql = "SELECT * FROM measurements WHERE customer_id = ? ORDER BY created_at DESC LIMIT 1";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractMeasurementFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع المقاسات: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Measurement> getAllMeasurementsByCustomerId(int customerId) {
        List<Measurement> measurements = new ArrayList<>();
        String sql = "SELECT * FROM measurements WHERE customer_id = ? ORDER BY created_at DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    measurements.add(extractMeasurementFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع المقاسات: " + e.getMessage());
            e.printStackTrace();
        }
        return measurements;
    }
    
    public boolean updateMeasurement(Measurement measurement) {
        String sql = "UPDATE measurements SET pants_type = ?, pants_length = ?, leg = ?, leg_type = ?, detail = ?, length = ?, sleeve = ?, safra = ?, pocket = ?, bshleik = ?, fit = ?, atk = ?, location = ?, updated_at = CURRENT_TIMESTAMP WHERE measurement_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, measurement.getPantsType());
            stmt.setString(2, measurement.getPantsLength());
            stmt.setString(3, measurement.getLeg());
            stmt.setString(4, measurement.getLegType());
            stmt.setString(5, measurement.getDetail());
            stmt.setString(6, measurement.getLength());
            stmt.setString(7, measurement.getSleeve());
            stmt.setString(8, measurement.getSafra());
            stmt.setString(9, measurement.getPocket());
            stmt.setString(10, measurement.getBshleik());
            stmt.setString(11, measurement.getFit());
            stmt.setString(12, measurement.getAtk());
            stmt.setString(13, measurement.getLocation());
            stmt.setInt(14, measurement.getMeasurementId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في تحديث المقاسات: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteMeasurement(int measurementId) {
        String sql = "DELETE FROM measurements WHERE measurement_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, measurementId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في حذف المقاسات: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    private Measurement extractMeasurementFromResultSet(ResultSet rs) throws SQLException {
        Measurement measurement = new Measurement();
        measurement.setMeasurementId(rs.getInt("measurement_id"));
        measurement.setCustomerId(rs.getInt("customer_id"));
        measurement.setPantsType(rs.getString("pants_type"));
        measurement.setPantsLength(rs.getString("pants_length"));
        measurement.setLeg(rs.getString("leg"));
        measurement.setLegType(rs.getString("leg_type"));
        measurement.setDetail(rs.getString("detail"));
        measurement.setLength(rs.getString("length"));
        measurement.setSleeve(rs.getString("sleeve"));
        measurement.setSafra(rs.getString("safra"));
        measurement.setPocket(rs.getString("pocket"));
        measurement.setBshleik(rs.getString("bshleik"));
        measurement.setFit(rs.getString("fit"));
        measurement.setAtk(rs.getString("atk"));
        measurement.setLocation(rs.getString("location"));
        measurement.setCreatedAt(rs.getTimestamp("created_at"));
        measurement.setUpdatedAt(rs.getTimestamp("updated_at"));
        return measurement;
    }
}

