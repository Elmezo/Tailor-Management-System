package ts.dao;

import ts.database.DatabaseConnection;
import ts.model.Customer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    private Connection connection;
    
    public CustomerDAO() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }
    
    public boolean createCustomer(Customer customer) {
        String sql = "INSERT INTO customers (customer_code, name, phone) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, customer.getCustomerCode());
            stmt.setString(2, customer.getName());
            stmt.setString(3, customer.getPhone());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        customer.setCustomerId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("خطأ في إنشاء العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public Customer getCustomerById(int customerId) {
        String sql = "SELECT * FROM customers WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractCustomerFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public Customer getCustomerByCode(String customerCode) {
        String sql = "SELECT * FROM customers WHERE customer_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customerCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractCustomerFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM customers ORDER BY created_at DESC";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                customers.add(extractCustomerFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("خطأ في استرجاع العملاء: " + e.getMessage());
            e.printStackTrace();
        }
        return customers;
    }
    
    public List<Customer> searchCustomers(String searchTerm) {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY created_at DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            String searchPattern = "%" + searchTerm + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    customers.add(extractCustomerFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في البحث عن العملاء: " + e.getMessage());
            e.printStackTrace();
        }
        return customers;
    }
    
    public boolean updateCustomer(Customer customer) {
        String sql = "UPDATE customers SET name = ?, phone = ?, updated_at = CURRENT_TIMESTAMP WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getPhone());
            stmt.setInt(3, customer.getCustomerId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في تحديث العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("خطأ في حذف العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean customerCodeExists(String customerCode) {
        String sql = "SELECT COUNT(*) FROM customers WHERE customer_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customerCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("خطأ في التحقق من كود العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    public String generateNextCustomerCode() {
        String sql = "SELECT customer_code FROM customers ORDER BY customer_id DESC LIMIT 1";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                String lastCode = rs.getString("customer_code");
                // Extract number from code like CUST001
                String prefix = lastCode.replaceAll("\\d", "");
                String number = lastCode.replaceAll("\\D", "");
                int nextNumber = Integer.parseInt(number) + 1;
                return String.format("%s%03d", prefix, nextNumber);
            } else {
                return "CUST001";
            }
        } catch (SQLException e) {
            System.err.println("خطأ في توليد كود العميل: " + e.getMessage());
            e.printStackTrace();
        }
        return "CUST001";
    }
    
    private Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerId(rs.getInt("customer_id"));
        customer.setCustomerCode(rs.getString("customer_code"));
        customer.setName(rs.getString("name"));
        customer.setPhone(rs.getString("phone"));
        customer.setCreatedAt(rs.getTimestamp("created_at"));
        customer.setUpdatedAt(rs.getTimestamp("updated_at"));
        return customer;
    }
}

